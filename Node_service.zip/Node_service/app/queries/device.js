import moment from 'moment';
import db from './../db';

module.exports = {
    hasPm2Permission: (peopleId) => {
        return db.Query(`SELECT 1 FROM People p 
        JOIN Client c ON c.ClientId = p.ClientId
        WHERE c.IsAustracker = 1 AND p.IsDeleted = 0 AND p.IsActive = 1 AND p.PeopleId = '${peopleId}'`);
    },
    validateDeviceIdentity: async (identity) => {
        return db.Query(`SELECT d.DeviceId,d.ClientId,d.ClientGroupId,d.HardwareProfileId,d.IsEnabled FROM Device d        
        WHERE d.IsDeleted = 0 AND d.IMEI = '${identity}'`);
    },
    associatedWith: async (val) => {
        return db.Query(`
        SELECT d.DeviceId,d.IsEnabled,d.HardwareProfileId, 
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN 'Vehicle' 
            WHEN a.CurrentDeviceId IS NOT NULL THEN ay.SystemCode 
            ELSE NULL END AS DeviceType,
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN v.VehicleId
            WHEN a.CurrentDeviceId IS NOT NULL THEN a.AssetId
            ELSE NULL END AS DeviceTypeId,
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN v.ClientGroupId
            WHEN a.CurrentDeviceId IS NOT NULL THEN a.ClientGroupId
            ELSE NULL END AS ClientGroupId,
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN v.ClientId
            WHEN a.CurrentDeviceId IS NOT NULL THEN a.ClientId
            ELSE NULL END AS ClientId,
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN v.DefaultDriverId            
            ELSE NULL END AS DriverId,
        CASE 
            WHEN v.CurrentDeviceId IS NOT NULL THEN v.IsPrivateTrip            
            ELSE NULL END AS TripType,		
		dm.UpdateTimeUTC as LastUpdateTimeUTC,
		dm.CurrentGeoLocation as  LastGeoLocation		
        FROM Device d
        LEFT JOIN Vehicle v ON v.CurrentDeviceId = d.DeviceId AND v.CurrentDeviceId IS NOT NULL
        LEFT JOIN Asset a ON a.CurrentDeviceId = d.DeviceId AND a.CurrentDeviceId IS NOT NULL
        LEFT JOIN AssetType ay ON ay.AssetTypeId = a.AssetTypeId
		LEFT JOIN (SELECT dm.DeviceId,dm.UpdateTimeUTC, dm.CurrentGeoLocation,
		(ROW_NUMBER() over (order by dm.UpdateTimeUTC desc)) as SeqNum FROM
		DeviceMessage dm ) as dm  ON dm.DeviceId = d.DeviceId  AND v.CurrentDeviceId IS NOT NULL AND dm.SeqNum=1
        WHERE d.IMEI = '${val}' AND d.IsDeleted = 0
        `);
    },
    fetchPlaces: async (clientId) => {        
        return db.Query(` SELECT p.PlaceId, p.Name, p.GeofenceCoordinates FROM Place p
        WHERE p.IsDeleted = 0 AND p.ClientId = '${clientId}' AND LEN(p.GeofenceCoordinates) > 0`);
    },
    addDeviceMessage: async (obj, trans) => {
        console.log(obj);
        return db.DeviceMessage.create(obj, { transaction: trans }).then(function (result) {
            return obj;
        }).catch(function (err) {
            throw new Error(err);
        });
    },
    addDeviceLog: async (obj) =>{
        
        return db.DeviceLog.create(obj).then(function (result) {
            return obj;
        }).catch(function (err) {
            throw new Error(err);
        });
    }
}