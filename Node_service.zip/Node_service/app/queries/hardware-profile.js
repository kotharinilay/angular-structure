
import db from './../db';

module.exports = {
    fetchHardwareProfiles: () => {
       return  db.Query(`
        SELECT hp.HardwareProfileId,hp.HardwareParserId, prs.ParserKey FROM HardwareProfile hp
        JOIN HardwareParser prs ON prs.HardwareParserId = hp.HardwareParserId
        WHERE hp.IsDeleted = 0`);
    },
    findParser: async (protocol, port) => {
       return  db.Query(`
        SELECT hp.HardwareProfileId,hp.HardwareParserId, prs.ParserKey FROM HardwareProfile hp
        JOIN HardwareParser prs ON prs.HardwareParserId = hp.HardwareParserId
        WHERE hp.IsDeleted = 0 AND hp.Protocol = '${protocol}' AND hp.PortNumber = '${port}'`);
    }
}