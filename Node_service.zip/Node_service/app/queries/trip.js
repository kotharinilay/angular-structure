

import db from './../db';

module.exports = {
    fetchActivityStatus: () => {
        return db.Query(`SELECT ActivityStatusId,SystemCode FROM ActivityStatus`);
    },
    fetchLastOpenTrip: async (vehicleId) => {
        return db.Query(`SELECT * FROM VehicleTrip
        WHERE VehicleId='${vehicleId}' AND JourneyEndDate IS NULL
        ORDER BY JourneyStartDate DESC`);
    },
    startTrip: async (obj, trans) => {
        return db.VehicleTrip.create(obj, { transaction: trans }).then(function (result) {
            return result;
        }).catch(function (err) {
            throw new Error(err);
        });
    },
    endTrip: async (obj, trans) => {
        return db.VehicleTrip.update(obj, { where: { VehicleTripId: obj.VehicleTripId } }, { transaction: trans }).then(function (result) {
            return result;
        }).catch(function (err) {
            throw new Error(err);
        });
    },
    updateVehicleOdometer: async (vehicleId, km, trans) => {
        return db.Exec(`
        UPDATE Vehicle SET TotalOdometerKM = ISNULL(TotalOdometerKM,0) + ${km} WHERE VehicleId = '${vehicleId}'
        `, trans); 
    }
}