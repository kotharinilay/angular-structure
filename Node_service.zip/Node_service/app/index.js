
// node modules
var http = require('http');
var express = require('express');
var bodyParser = require('body-parser');
var compression = require('compression');
var pm2 = require('pm2');

// custom modules
require('./env');

var db = require('./db');
import { headers, auth } from './middlewares';
var router = require('./api');

const app = new express();
const io = require('socket.io');
const socketServer = require('socket.io')(process.env.SOCKET_IO_PORT);
console.log(process.env.DB_HOST);
app.use(compression());
app.use(bodyParser.urlencoded({ limit: '150mb', extended: true }));
app.use(bodyParser.json({ limit: '150mb' }));

// if JWT is enabled
if (process.env.JWT_ENABLE == '1') {
    app.use('/api', headers, auth, router);
}
else {
    app.use('/api', headers, router);
}

// connect pm2
pm2.connect(serverConnect);

// connect to the database server
function dbConnect() {
    db.sequelize.authenticate()
        .then(function () {
            console.log("==> ✅ Database server connected ! ");
        })
        .catch(function (err) {
            console.log("==> Database connection error: " + err);
        })
        .done();
}

// initiate express server
function serverConnect(err) {
    if (err) {
        console.error("==> pm2 connect error: " + err);
        process.exit(2);
    }
    console.log('==> ✅ pm2 is connected');

    var port = process.env.ROOT_HTTP_PORT || 5000;
    // start the server and listen specified port

    var server = require('http').createServer(app)
    var ioServer = io.listen(server);

    ioServer.on('connection', function (socket) {
        console.log(socket.sockets);

        socket.on('emitMessage', function (data) {
            socketServer.emit('message', data);
        });
    });

    server.listen(port, err => {
        if (err) { return console.error("==> Express server error: " + err); }
        console.info("==> ✅ Express server is listening");
        console.info(`==> 🌎 Go to http://localhost:${port}`);

        dbConnect();
    });
}
