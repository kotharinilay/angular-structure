'use strict';

import pm2 from 'pm2';
import Promise from 'bluebird';
import path from 'path';
import { hasPm2Permission } from '../queries/device';

module.exports =
    {
        start: (protocol, port) => {
            return new Promise((success, error) => {
                
                let opt = {
                    script: path.join(process.cwd(),`/build/protocol/${protocol}.js`),
                    name: port,
                    args: [port],                    
                    watch: true
                };
                pm2.start(opt,  function(err, proc) {                    
                    if (err) {                     
                       error(err);
                    }                    
                    success();
                });
            });
        },
        hasPermission: (payload) =>{            
            return hasPm2Permission("").then((data) =>{
                console.log(data);
            }).catch((err) =>{

            });
        }
    }