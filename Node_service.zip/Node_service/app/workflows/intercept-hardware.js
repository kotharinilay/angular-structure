'use strict';

//TODO:
// Alerts
// JWT auth
// Error logging

import Promise from 'bluebird';
import geolib from 'geolib';
import GoogleMapsAPI from 'googlemaps';
import { v4 as uuidv4 } from 'uuid';
import moment from 'moment';
import { map, flatten } from 'lodash';

import db from './../db';
import { findParser } from './../queries/hardware-profile';
import { fetchPlaces, associatedWith, addDeviceMessage } from './../queries/device';
import { fetchLastOpenTrip, startTrip, endTrip, updateVehicleOdometer } from './../queries/trip';

var socketClient = require('socket.io-client');
var socket = socketClient.connect(`${process.env.ROOT_HTTP_HOST}:${process.env.ROOT_HTTP_PORT}`);

var GoogleApi = new GoogleMapsAPI({ key: process.env.GOOGLE_API_KEY });

let Payload = null, DeviceInfo = null, Message = null, HardwareProfile = null, Parser = null,
    PlaceId = null, PlaceName = null;

module.exports =
    {
        interceptMessage: async (protocol, port, message) => {

            Payload = null, DeviceInfo = null, Message = message, Parser = null;

            // find correct parser key from database
            HardwareProfile = await detectParser(protocol, port);
            if (HardwareProfile == null) {
                throw new Error('Hardware Profile is not attached to the port.');
            }

            // decode message according to parser logic
            await decodeWithParser();

            // retrieve basic device info
            DeviceInfo = await fetchDeviceInfo();

            await isCoordinateInside();
            await findLocation();

            return db.sequelize.transaction(async (t) => {
                let vehicalTripObj = await vehicleTrip(t);
                let deviceMessageObj = await logMessage(vehicalTripObj, t);
                console.log('before emit');
                socket.emit('emitMessage', { vehicalTripObj: vehicalTripObj, deviceMessageObj: deviceMessageObj });
                return { SendAckMessage: Parser.SendAckMessage, AckMessage: Parser.Ack(Payload), AckMessageType: Parser.AckMessageType };
            });
        }
    }

// fetch the respective parser of device
let detectParser = async (protocol, port) => {
    let data = await findParser(protocol, port);
    if (data.length == 0) {
        throw new Error("Parser not found");
    }
    return data[0];
}

// decode hex message 
let decodeWithParser = async () => {
    try {
        Parser = require('./../parser/' + HardwareProfile.ParserKey + '.js');
        Payload = Parser.Decode(Message);
    }
    catch (err) {
        throw err;
    }
    //Payload.DbColumns.Longitude += ((Math.random() > 0.5 ? 0.001 : -0.009) + Math.random() * 0.008);
    //Payload.DbColumns.Latitude += ((Math.random() > 0.5 ? 0.001 : -0.009) + Math.random() * 0.008);
}

// retrieve device related info from database
// to verify identity
let fetchDeviceInfo = async () => {
    let { IMEI } = Payload.DbColumns;
    let data = await associatedWith(IMEI);

    if (data.length == 0)
        throw new Error(`No device found with identity:${IMEI}`);
    if (data.length > 1)
        throw new Error(`Device ${IMEI} is associated with multiple vehicles/assets`);

    if (data[0].IsEnabled == false)
        throw new Error(`Device is disabled`);

    console.log(data);
    return data[0];
}

// Check if geo point is falling between any fence area of places
let isCoordinateInside = async () => {
    let { ClientId } = DeviceInfo;
    let places = await fetchPlaces(ClientId);

    let geo = [], placeId = null;
    let { Latitude, Longitude } = Payload.DbColumns;

    for (var m = 0; m < places.length; m++) {
        places[m].GeofenceCoordinates = JSON.parse(places[m].GeofenceCoordinates);
        for (var g of places[m].GeofenceCoordinates) {
            geo.push({ latitude: g.lat, longitude: g.lng });
        }
        var inside = geolib.isPointInside({ latitude: Latitude, longitude: Longitude }, geo);
        if (inside == true) {
            placeId = places[m].PlaceId;
            break;
        }
    };
    console.log('isCoodinateInside');
    PlaceId = placeId;
}

// insert current device message to the database
let logMessage = async (trip, t) => {

    let { ClientId, DeviceType, DeviceTypeId, ClientGroupId, TripType, DeviceId } = DeviceInfo;
    let { Latitude, Longitude, SequenceNo, Altitude, Speed, Hdop, Ignition, UpdateTime } = Payload.DbColumns;

    // trip must exist for vehicle
    if (DeviceType == 'Vehicle' && trip == null)
        return null;

    return await addDeviceMessage({
        DeviceMessageId: uuidv4(),
        MessageReceivedUTC: moment.utc(),
        UpdateTimeUTC: moment(UpdateTime),
        MessageId: SequenceNo,
        VehicleTripId: trip != null ? trip.VehicleTripId : null,
        VehicleId: (DeviceType == 'Vehicle' ? DeviceTypeId : null),
        AssetId: (DeviceType != 'Vehicle' ? DeviceTypeId : null),
        DeviceId: DeviceId,
        HardwareProfileId: HardwareProfile.HardwareProfileId,
        HardwareParserId: HardwareProfile.HardwareParserId,
        MessageString: Payload.HexMessage,
        BinaryData: JSON.stringify(Payload.DecodedJson),
        CurrentPlaceId: PlaceId,
        CurrentPlaceName: PlaceName,
        CurrentGeoLocation: `${Latitude},${Longitude}`,
        Altitude: Altitude,
        LocationDistance: trip != null ? trip.LocationDistance : 0,
        Speed: Speed,
        Hdop: Hdop,
        Ignition: Ignition
    }, t);
}

// update existing running trip OR 
// create new trip based on the Ignition Status
let vehicleTrip = async (t) => {

    let { ClientId, DeviceType, DeviceTypeId, ClientGroupId, TripType, DeviceId, DriverId, LastUpdateTimeUTC, LastGeoLocation } = DeviceInfo;
    let { Latitude, Longitude, SequenceNo, Altitude, OdometerKM, Speed, Hdop, Ignition, UpdateTime } = Payload.DbColumns;

    let response = {};

    if (DeviceInfo.DeviceType == 'Vehicle') {

        let trips = await fetchLastOpenTrip(DeviceTypeId);
        if (trips.length > 0) {
            let currentTrip = trips[0];
            if (Ignition == false) {
                // Complete trip if Ignition is Off
                currentTrip.DestinationPlaceId = PlaceId;
                currentTrip.DestinationPlaceName = PlaceName;
                currentTrip.DestinationGeoLocation = `${Latitude},${Longitude}`;
                currentTrip.JourneyEndDate = moment(UpdateTime);
            }

            if (currentTrip.JourneyDuration == null || currentTrip.JourneyDuration == '')
                currentTrip.JourneyDuration = 0;
            if (currentTrip.JourneyDistance == null || currentTrip.JourneyDistance == '')
                currentTrip.JourneyDistance = 0;

            if (LastUpdateTimeUTC != null)
                currentTrip.JourneyDuration += moment(UpdateTime).diff(moment(LastUpdateTimeUTC), 'seconds');

            let distance = await findDistance(LastGeoLocation, `${Latitude},${Longitude}`);
            currentTrip.JourneyDistance += distance;

            await endTrip(currentTrip, t);
            currentTrip.LocationDistance = distance;
            return currentTrip;
        }
        else {
            if (Ignition == true) {
                // Start new trip
                let currentTrip = {
                    VehicleTripId: uuidv4(),
                    VehicleId: DeviceTypeId,
                    ClientId: ClientId,
                    ClientGroupId: ClientGroupId,
                    DriverId: DriverId,
                    FromPlaceId: PlaceId,
                    FromPlaceName: PlaceName,
                    FromGeoLocation: `${Latitude},${Longitude}`,
                    JourneyStartDate: moment(UpdateTime),
                    JourneyDistance: 0,
                    IsPrivateTrip: TripType
                };

                await startTrip(currentTrip, t)
                currentTrip.LocationDistance = 0;
                return currentTrip;
            }
        }
    }

    return null;
}

// find location address using geo points
// using google map api
let findLocation = async () => {
    let { Latitude, Longitude } = Payload.DbColumns;
    PlaceName = null;

    return new Promise((resolve, reject) => {
        GoogleApi.reverseGeocode({ latlng: `${Latitude},${Longitude}`, "language": "en" }, (err, data) => {
            if (err)
                reject(err);

            if (data.results.length > 0) {
                PlaceName = data.results[0].formatted_address;
            }
            resolve();
        });
    })
}

//  find distance in km between two geo points
//  using google map api 
let findDistance = async (source, destination) => {
    return new Promise((resolve, reject) => {

        if (source == null || destination == null) {
            console.log("Cannot calculate distance. Source or destination is null");
            console.log(source);
            console.log(destination);
            resolve(0);
        }

        var params = {
            origins: source,
            destinations: destination,
            mode: 'driving',
            units: 'metric'
        };
        console.log(params);
        GoogleApi.distance(params, function (err, result) {
            if (err)
                reject(err);

            console.log(result);
            if (result.rows.length > 0 && result.rows[0].elements.length > 0) {
                // value received in meter
                resolve(result.rows[0].elements[0].distance.value / 1000);
            }
        })
    });
}
