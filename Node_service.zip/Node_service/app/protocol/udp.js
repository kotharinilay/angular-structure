
var dgram = require('dgram');
import moment from 'moment';
import { interceptMessage } from './../workflows/intercept-hardware';
import { decode, ack } from './../parser/calamp-obd2';
import { addDeviceLog } from './../queries/device';
import { v4 as uuidv4 } from 'uuid';
var BitArray = require('node-bitarray');

var server = dgram.createSocket('udp4');
var host = '192.168.1.127';
var port = process.argv[2];

console.log(process.argv);

server.on('listening', function () {
    var address = server.address();
    console.log('UDP Server listening on ' + address.address + ":" + address.port);
});

server.on('message', async (message, remote) => {
    console.log('Message Received');
    console.log(new Date());
    console.log(message.toString('hex'));
    var address = server.address();

    try {
        await addDeviceLog({
            Protocol: 'udp',
            DeviceLogId: uuidv4(),
            Message: message.toString('hex'),
            RemoteIp: remote.address,
            RemotePort: remote.port,
            TargetIp: address.address,
            TargetPort: address.port,
            ReceivedAtUTC: moment.utc()
        });

        let data = await interceptMessage('udp', address.port, message);
        await sendAck(data, remote);
    } catch (err) {
        console.log(err);
    }
});

let sendAck = async (data, remote) => {
    if (data.SendAckMessage == true) {
        var byteArray = Buffer.from(data.AckMessage, data.AckMessageType);
        server.send(byteArray, 0, byteArray.length, remote.port, remote.address, (err, bytes) => {
            if (err) throw err;
            console.log('ACK sent ' + bytes);
        });
    }
}

server.bind(port, host);