'use strict';

import { hardware as endpoint } from './../config/endpoint';
import { fetchHardwareProfiles } from './../queries/hardware-profile';
import esky from './../parser/esky';

var PORT = 42523;
var HOST = '192.168.1.127';

var dgram = require('dgram');
var message = new Buffer('08605850032947655200599d33b300636171ff0000000000000000000000000000000000040027b782000004d70dacad', 'hex');

module.exports = (router) => {
    router.get('/udpsend', function (req, res, next) {
        
        var client = dgram.createSocket('udp4');
        client.send(message, 0, message.length, PORT, HOST, function (err, bytes) {
            if (err) throw err;
            //res.io.emit('message', "this is test IO event..");
            console.log('UDP message sent to ' + HOST + ':' + PORT);
            console.log(bytes);
            client.close();
        }); 

        return res.status(200).send();
    })
    router.get(endpoint.FetchAllProfilesFromDb, function (req, res, next) {
        return fetchHardwareProfiles().then(function (data) {
            return res.status(200).send(data);
        }).catch(function (err) {
            next(err);
        });
    });
}