'use strict';

import Express from 'express';

// create router instance
var router = Express.Router();

require('./hardware')(router);
require('./pm2')(router);

module.exports = router;    