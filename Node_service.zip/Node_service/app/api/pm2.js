'use strict';

import server from './../workflows/server-protocol';
import { pm2 as endpoint } from './../config/endpoint';
import { isNullOrEmpty } from './../lib/utility';

module.exports = (router) => {
    router.post(endpoint.StartSpecificServer, (req, res, next) => {
        var port = req.query.port;
        var protocol = req.query.protocol

        if (isNullOrEmpty(protocol)) {
            return res.status(400).send('Protocol is mandatory.');
        }
        if (isNullOrEmpty(port)) {
            return res.status(400).send('Port is mandatory.');
        }       
       
        return server.start(protocol, port).then(() => {
            return res.status(200).send(`==> ${protocol}:${port} is listening now.`);
        }).catch((err) => {
            next(err);
        });
    });
    router.post(endpoint.StartAllServers, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.StopSpecificServer, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.StopAllServers, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.RemoveSpecificServer, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.RemoveAllServers, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.RemoveSpecificServer, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
    router.post(endpoint.RestartAllServers, function (req, res, next) {
        return res.status(400).send('Not implemented yet!');
    });
}    