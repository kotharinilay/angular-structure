
import BitArray from 'node-bitarray';
import { cmToKph, cmToMph, binaryToDecimal, replaceAll, binaryToHex, hexToAscii, UnixTimeStamp } from './../lib/utility';
import { slice as _slice, map as _map } from 'lodash';
import { Coordinate } from './../lib/calamp';

let fieldsObj = {
    IMEI: null,
    ReportType: null,
    SequenceNumber: null,
    GeneratedDateUTC: null,    
    SatelliteCount: null,
    HDOP: null,
    GPSFixDateUTC: null,    
    Latitude: null,
    Longitude: null,
    Speed: null,
    Heading: null,
    Inputs: null,
    Outputs: null,
    EventType: null,
    DistanceLog: null,
    ADCVolts: null,
    ExternalVolts: null,
    BackupVolts: null,
    RSSI: null
};

module.exports = {
    SendAckMessage: true,
    AckMessageType: 'hex',
    Decode: (message) => {

        let buffer = Buffer.from(message, 'hex');
        let bitArray = [];

        for (var b of buffer) {
            bitArray.push(BitArray.fromBuffer([b]));
        }

        let parseIndex = 0;

        /********************* IMEI **********************/
        let imeiBit = _slice(bitArray, parseIndex, 8);
        fieldsObj.IMEI = convertToDataObj(imeiBit);
        fieldsObj.IMEI.Decoded = fieldsObj.IMEI.Hex;
        parseIndex += 8;

        /********************* REPORT TYPE **********************/
        let reportTypeBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.ReportType = convertToDataObj(reportTypeBit);
        fieldsObj.ReportType.Decoded = hexToAscii(fieldsObj.ReportType.Hex);

        /********************* SEQUENCE NO **********************/
        let seqBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.SequenceNumber = convertToDataObj(seqBit);
        fieldsObj.SequenceNumber.Decoded = fieldsObj.SequenceNumber.Decimal;

        /********************* GENERATED DATETIME **********************/
        let generatedDateBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.GeneratedDateUTC = convertToDataObj(generatedDateBit);
        fieldsObj.GeneratedDateUTC.Decoded = UnixTimeStamp(fieldsObj.GeneratedDateUTC.Decimal);

        /********************* SATELLITE COUNT **********************/
        let satelliteBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.SatelliteCount = convertToDataObj(satelliteBit);
        fieldsObj.SatelliteCount.Decoded = fieldsObj.SatelliteCount.Decimal;

        /********************* HDOP COUNT **********************/
        let hdopBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.HDOP = convertToDataObj(hdopBit);
        fieldsObj.HDOP.Decoded = fieldsObj.HDOP.Decimal / 10;

        /********************* GPS FIX DATE **********************/
        let gpsFixDateBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.GPSFixDateUTC = convertToDataObj(gpsFixDateBit);
        fieldsObj.GPSFixDateUTC.Decoded = UnixTimeStamp(fieldsObj.GPSFixDateUTC.Decimal);

        /********************* LATITUDE **********************/
        let latitudeBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.Latitude = convertToDataObj(latitudeBit);
        fieldsObj.Latitude.Decoded = Coordinate(fieldsObj.Latitude.Hex);

        /********************* LONGITUDE **********************/
        let longitudeBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.Longitude = convertToDataObj(longitudeBit);
        fieldsObj.Longitude.Decoded = Coordinate(fieldsObj.Longitude.Hex);

        /********************* SPEED **********************/
        let speedBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.Speed = convertToDataObj(speedBit);
        fieldsObj.Speed.Decoded = cmToKph(fieldsObj.Speed.Decimal);

        /********************* HEADING **********************/
        let headingBit = _slice(bitArray, parseIndex, parseIndex += 2);
        fieldsObj.Heading = convertToDataObj(headingBit);
        fieldsObj.Heading.Decoded = fieldsObj.Heading.Decimal;

        /********************* INPUTS **********************/
        let inputsBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.Inputs = convertToDataObj(inputsBit);
        fieldsObj.Inputs.Decoded = fieldsObj.Inputs.Decimal;

        /********************* OUTPUTS **********************/
        let outputsBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.Outputs = convertToDataObj(outputsBit);
        fieldsObj.Outputs.Decoded = fieldsObj.Outputs.Decimal;

        /********************* EVENT TYPES **********************/
        let eventTypesBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.EventType = convertToDataObj(eventTypesBit);

        switch (fieldsObj.EventType.Decimal) {
            case 0:
                fieldsObj.EventType.Decoded = "Interval";
                break;
            case 1:
                fieldsObj.EventType.Decoded = "Vibration";
                break;
            case 2:
                fieldsObj.EventType.Decoded = "PowerDisconnect";
                break;
            case 3:
                fieldsObj.EventType.Decoded = "PowerConnect";
                break;
            case 4:
                fieldsObj.EventType.Decoded = "IgnitionOn";
                break;
            case 5:
                fieldsObj.EventType.Decoded = "IgnitionOff";
                break;
            case 6:
                fieldsObj.EventType.Decoded = "Input1High";
                break;
            case 7:
                fieldsObj.EventType.Decoded = "Input1Low";
                break;
            case 8:
                fieldsObj.EventType.Decoded = "StoppedMoving";
                break;
            case 9:
                fieldsObj.EventType.Decoded = "Heartbeat";
                break;
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 18:
            case 20:
            case 21:
            case 22:
            case 23:
                break;
            case 15:
                fieldsObj.EventType.Decoded = "Input2High";
                break;
            case 16:
                fieldsObj.EventType.Decoded = "Input2Low";
                break;
            case 17:
                fieldsObj.EventType.Decoded = "HardBreaking";
                break;
            case 19:
                fieldsObj.EventType.Decoded = "CrashDetected";
                break;
            case 24:
                fieldsObj.EventType.Decoded = "HeadingChanged";
                break;
            case 25:
                fieldsObj.EventType.Decoded = "TowAlert";
                break;
            case 35:
                fieldsObj.EventType.Decoded = "OutputSet";
                break;
            case 36:
                fieldsObj.EventType.Decoded = "OutputCleared";
                break;
            default:
                fieldsObj.EventType.Decoded = "UnspecifiedEvent";
                break;
        }

        /********************* DISTNACE LOG **********************/
        let distanceLogBit = _slice(bitArray, parseIndex, parseIndex += 4);
        fieldsObj.DistanceLog = convertToDataObj(distanceLogBit);
        fieldsObj.DistanceLog.Decoded = fieldsObj.DistanceLog.Decimal / 1000 + ' KM';

        /********************* ADC VOLTS **********************/
        let adcBit = _slice(bitArray, parseIndex, parseIndex += 2);
        fieldsObj.ADCVolts = convertToDataObj(distanceLogBit);
        fieldsObj.ADCVolts.Decoded = fieldsObj.ADCVolts.Decimal / 100 + ' Volts';

        /********************* EXTERNAL VOLTS **********************/
        let extBit = _slice(bitArray, parseIndex, parseIndex += 2);
        fieldsObj.ExternalVolts = convertToDataObj(extBit);
        fieldsObj.ExternalVolts.Decoded = fieldsObj.ExternalVolts.Decimal / 100 + ' Volts';

        /********************* BACKUP VOLTS **********************/
        let backupBit = _slice(bitArray, parseIndex, parseIndex += 2);
        fieldsObj.BackupVolts = convertToDataObj(backupBit);
        fieldsObj.BackupVolts.Decoded = fieldsObj.BackupVolts.Decimal / 1000 + ' Volts';

        /********************* RSSI **********************/
        let rssiBit = _slice(bitArray, parseIndex, ++parseIndex);
        fieldsObj.RSSI = convertToDataObj(rssiBit);
        fieldsObj.RSSI.Decoded = fieldsObj.RSSI.Decimal;

        console.log(fieldsObj);

        // deallocate heap
        buffer = null;
        bitArray = null;

        return {
            DecodedJson: fieldsObj,
            HexMessage: message.toString('hex'),
            DbColumns: dbColumns(fieldsObj)
        };
    },
    Ack: (payload) => {
        
        // format : ACK + SequenceNumber
        // Hex value of "ACK" equals to "41434b"        
        
        let decodedJson = payload.DecodedJson;
        let hex = `41434b${decodedJson.SequenceNumber.Hex}`;
        return hex;
    }
}

let convertToDataObj = (obj) => {
    if (Array.isArray(obj) == false) { // if object
        obj = cleanValue(obj);
    }
    else { // if Array
        let bin = '';
        _map(obj, (i) => {
            bin += cleanValue(i);
        });
        obj = bin;
    }

    return {
        Binary: obj,
        Hex: binaryToHex(obj),
        Decimal: binaryToDecimal(obj)
    };
}

let cleanValue = (bit) => { return replaceAll(jsonToString(bit), ",", "") };
let jsonToString = (bitArr) => { return bitArr.toJSON().toString(); };

let dbColumns = (payload) => {
    if (payload == null)
        return null;

    let { IMEI, Longitude, Latitude, SequenceNumber, Speed, HDOP, Heading, GeneratedDateUTC, Inputs } = payload;

    return {
        IMEI: IMEI.Decoded,
        Longitude: Longitude.Decoded,
        Latitude: Latitude.Decoded,
        Altitude: Heading.Decoded,
        SequenceNo: SequenceNumber.Decoded,
        Speed: Speed.Decoded,
        Hdop: HDOP.Decoded,
        UpdateTime: GeneratedDateUTC.Decoded,
        OdometerKM: 0,
        Ignition: Inputs.Decimal == "IgnitionOn" ? true : false
    }
}