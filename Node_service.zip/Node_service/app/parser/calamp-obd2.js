'use strict';

import BitArray from 'node-bitarray';
import { UnixTimeStamp,cmToKph, cmToMph, binaryToDecimal, replaceAll, binaryToHex } from './../lib/utility';
import { slice as _slice, map as _map } from 'lodash';
import calamp from './../lib/calamp';

module.exports = {
    SendAckMessage: true,
    AckMessageType:'hex',
    Decode: (message) => {

        let buffer = new Buffer(message);
        let bitArray = [];

        for (var b of buffer) {
            bitArray.push(BitArray.fromBuffer([b]));
        }

        let optionsByte = bitArray[0];
        if (optionsByte.get(0) == 1) {

            fieldsObj.OptionsByte = convertToDataObj(optionsByte);

            let hasMobileId = optionsByte.get(7);
            let hasAuthenticationWord = optionsByte.get(6);
            let hasRouting = optionsByte.get(5);
            let hasForwarding = optionsByte.get(3);
            let hasResponseRedirection = optionsByte.get(2);

            let parseIndex = 1;
            if (hasMobileId == 1) {
                fieldsObj.OptionsByte.Decoded = "MobileID,MobileIDType";
                /********************* MOBILE ID **********************/
                fieldsObj.MobileIDLength = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.MobileIDLength.Decoded = fieldsObj.MobileIDLength.Decimal + ' Bytes';

                parseIndex++;
                let endLength = (fieldsObj.MobileIDLength.Decimal + parseIndex);
                let mobileIdBit = _slice(bitArray, parseIndex, endLength);
                fieldsObj.MobileID = convertToDataObj(mobileIdBit);
                fieldsObj.MobileID.Decoded = fieldsObj.MobileID.Hex;

                /********************* MOBILE ID TYPE **********************/
                parseIndex = endLength;
                fieldsObj.MobileIDTypeLength = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.MobileIDTypeLength.Decoded = fieldsObj.MobileIDTypeLength.Decimal + ' Bytes';

                parseIndex++;
                endLength = fieldsObj.MobileIDTypeLength.Decimal + parseIndex;
                let mobileTypeBit = _slice(bitArray, parseIndex, endLength);
                fieldsObj.MobileIDType = convertToDataObj(mobileTypeBit);
                fieldsObj.MobileIDType.Decoded = calamp.MobileIdType(fieldsObj.MobileIDType.Decimal);
                parseIndex = endLength;
            }
            if (hasAuthenticationWord == 1) {
                /********************* AUTHENTICATION LENGTH **********************/
                /********************* AUTHENTICATION **********************/
            }
            if (hasRouting == 1) {
                /********************* ROUTING LENGTH **********************/
                /********************* ROUTING **********************/
            }
            if (hasForwarding == 1) {
                /********************* FORWARDING LENGTH **********************/
                /********************* FORWARDING **********************/
            }
            if (hasResponseRedirection == 1) {
                /********************* RESPONSE REDIRECT LENGTH **********************/
                /********************* RESPONSE REDIRECT **********************/
            }

            /********************* SERVICE TYPE **********************/
            fieldsObj.ServiceType = convertToDataObj(bitArray[parseIndex]);
            fieldsObj.ServiceType.Decoded = calamp.ServiceType(fieldsObj.ServiceType.Decimal);

            /********************* MESSAGE TYPE **********************/
            parseIndex++;
            fieldsObj.MessageType = convertToDataObj(bitArray[parseIndex]);
            if (fieldsObj.MessageType.Decimal == 2) {  // Event Message Report
                fieldsObj.MessageType.Decoded = calamp.MessageType(fieldsObj.MessageType.Decimal);

                /********************* SEQUENCE # **********************/
                parseIndex++;
                let sequenceBit = _slice(bitArray, parseIndex, parseIndex + 2);
                console.log('sequenceBit');
                console.log(sequenceBit);
                fieldsObj.SequenceNo = convertToDataObj(sequenceBit);
                fieldsObj.SequenceNo.Decoded = fieldsObj.SequenceNo.Decimal;
                parseIndex += 2;

                /********************* UPDATE TIME **********************/
                let updateTimeBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.UpdateTime = convertToDataObj(updateTimeBit);
                fieldsObj.UpdateTime.Decoded = UnixTimeStamp(fieldsObj.UpdateTime.Decimal);
                parseIndex += 4;

                /********************* TIME OF FIX **********************/
                let timeOfFixBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.TimeOfFix = convertToDataObj(timeOfFixBit);
                fieldsObj.TimeOfFix.Decoded = UnixTimeStamp(fieldsObj.TimeOfFix.Decimal);
                parseIndex += 4;

                /********************* LATITUDE **********************/
                let latitudeBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.Latitude = convertToDataObj(latitudeBit);
                fieldsObj.Latitude.Decoded = calamp.Coordinate(fieldsObj.Latitude.Hex);
                parseIndex += 4;

                /********************* LONGITUDE **********************/
                let longitudeBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.Longitude = convertToDataObj(longitudeBit);
                fieldsObj.Longitude.Decoded = calamp.Coordinate(fieldsObj.Longitude.Hex);
                parseIndex += 4;

                /********************* ALTITUDE **********************/
                let altitudeBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.Altitude = convertToDataObj(altitudeBit);
                fieldsObj.Altitude.Decoded = fieldsObj.Altitude.Decimal;
                parseIndex += 4;

                /********************* SPEED **********************/
                let speedBit = _slice(bitArray, parseIndex, parseIndex + 4);
                fieldsObj.Speed = convertToDataObj(speedBit);
                fieldsObj.Speed.Decoded = cmToKph(fieldsObj.Speed.Decimal);
                parseIndex += 4;

                /********************* HEADING **********************/
                let headingBit = _slice(bitArray, parseIndex, parseIndex + 2);
                fieldsObj.Heading = convertToDataObj(headingBit);
                fieldsObj.Heading.Decoded = fieldsObj.Heading.Decimal;
                parseIndex += 2;

                /********************* SATELLITES **********************/
                fieldsObj.Satellites = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.Satellites.Decoded = fieldsObj.Satellites.Decimal;
                parseIndex++;

                /********************* FIX STATUS **********************/
                fieldsObj.FixStatus = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.FixStatus.Decoded = '';
                if (bitArray[parseIndex].get(1) == 1) {
                    fieldsObj.FixStatus.Decoded += "InvalidTime";
                }
                if (bitArray[parseIndex].get(2) == 1) {
                    fieldsObj.FixStatus.Decoded += ",Historic";
                }
                if (bitArray[parseIndex].get(3) == 1) {
                    fieldsObj.FixStatus.Decoded += ",2DFix";
                }
                if (bitArray[parseIndex].get(4) == 1) {
                    fieldsObj.FixStatus.Decoded += ",InvalidFix";
                }
                if (bitArray[parseIndex].get(5) == 1) {
                    fieldsObj.FixStatus.Decoded += ",LastKnown";
                }
                if (bitArray[parseIndex].get(6) == 1) {
                    fieldsObj.FixStatus.Decoded += ",DifferentiallyCorrected";
                }
                if (bitArray[parseIndex].get(7) == 1) {
                    fieldsObj.FixStatus.Decoded += ",Predicted";
                }
                parseIndex++;

                /********************* CARRIER **********************/
                let carrierBit = _slice(bitArray, parseIndex, parseIndex + 2);
                fieldsObj.Carrier = convertToDataObj(carrierBit);
                fieldsObj.Carrier.Decoded = fieldsObj.Carrier.Decimal;
                parseIndex += 2;

                /********************* RSSI **********************/
                let rssiBit = _slice(bitArray, parseIndex, parseIndex + 2);
                fieldsObj.RSSI = convertToDataObj(rssiBit);
                fieldsObj.RSSI.Decoded = calamp.RSSI(fieldsObj.RSSI.Hex);
                parseIndex += 2;

                /********************* COMM STATE **********************/
                fieldsObj.CommState = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.CommState.Decoded = '';
                if (bitArray[parseIndex].get(1) == 1) {
                    fieldsObj.FixStatus.Decoded += ",3G";
                }
                if (bitArray[parseIndex].get(2) == 1) {
                    fieldsObj.FixStatus.Decoded += ",Roaming";
                }
                if (bitArray[parseIndex].get(3) == 1) {
                    fieldsObj.FixStatus.Decoded += ",VoiceCallIsActive";
                }
                if (bitArray[parseIndex].get(4) == 1) {
                    fieldsObj.FixStatus.Decoded += ",Connected";
                }
                if (bitArray[parseIndex].get(5) == 1) {
                    fieldsObj.FixStatus.Decoded += ",DataService";
                }
                if (bitArray[parseIndex].get(6) == 1) {
                    fieldsObj.FixStatus.Decoded += ",NetworkService";
                }
                if (bitArray[parseIndex].get(7) == 1) {
                    fieldsObj.FixStatus.Decoded += ",Available";
                }
                parseIndex++;

                /********************* HDOP **********************/
                fieldsObj.HDOP = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.HDOP.Decoded = fieldsObj.HDOP.Decimal;
                parseIndex++;

                /********************* INPUTS **********************/
                fieldsObj.Inputs = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.Inputs.Decoded = '';
                
                if (bitArray[parseIndex].get(7) == 1) {
                    fieldsObj.Inputs.Decoded += "IgnitionOn";
                }
                if (bitArray[parseIndex].get(7) == 0) {
                    fieldsObj.Inputs.Decoded += "IgnitionOff";
                }
                console.log(fieldsObj.Inputs);
                parseIndex++;

                /********************* UNIT STATUS  **********************/
                fieldsObj.UnitStatus = convertToDataObj(bitArray[parseIndex]);
                if (bitArray[parseIndex].get(1) == 1) {
                    fieldsObj.FixStatus.Decoded += ",GPSExceptionReported";
                }
                if (bitArray[parseIndex].get(3) == 1) {
                    fieldsObj.FixStatus.Decoded += ",ModemMINTestError";
                }
                if (bitArray[parseIndex].get(4) == 1) {
                    fieldsObj.FixStatus.Decoded += ",GPSReceiverNotTracking";
                }
                if (bitArray[parseIndex].get(5) == 1) {
                    fieldsObj.FixStatus.Decoded += ",GPSReceiverSelfTestError";
                }
                if (bitArray[parseIndex].get(6) == 1) {
                    fieldsObj.FixStatus.Decoded += ",GPSAntennaError";
                }
                if (bitArray[parseIndex].get(7) == 1) {
                    fieldsObj.FixStatus.Decoded += ",MemoryTestError";
                }
                parseIndex++;

                /********************* EVENT INDEX  **********************/
                fieldsObj.EventIndex = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.EventIndex.Decoded = fieldsObj.EventIndex.Decimal;
                parseIndex++;

                /********************* EVENT CODE  **********************/
                fieldsObj.EventCode = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.EventCode.Decoded = fieldsObj.EventCode.Decimal;
                parseIndex++;

                /********************* ACCUM COUNT  **********************/
                fieldsObj.AccumCount = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.AccumCount.Decoded = fieldsObj.AccumCount.Decimal;
                parseIndex++;

                /********************* SPARE  **********************/
                fieldsObj.Spare = convertToDataObj(bitArray[parseIndex]);
                fieldsObj.Spare.Decoded = fieldsObj.Spare.Decimal;
                parseIndex++;

                /********************* ACCUM N' **********************/
                for (var i = 0; i < fieldsObj.AccumCount.Decoded; i++) {
                    let accumBit = _slice(bitArray, parseIndex, parseIndex + 4);
                    let nameOf = 'Accum' + i;
                    fieldsObj[nameOf] = convertToDataObj(accumBit);
                    fieldsObj[nameOf].Decoded = fieldsObj[nameOf].Decimal;
                    parseIndex += 4;
                };
            }
            else {
                //throw Exception("MessageType is not 02:Event");
            }
        }
        else {
            console.log('Option Bytes is not present in the message. Cannot decode message !');
        }

        // deallocate heap
        buffer = null;
        bitArray = null;

        return {
            DecodedJson: fieldsObj,
            HexMessage: message.toString('hex'),
            DbColumns: dbColumns(fieldsObj)
        };
    },
    Ack: (payload) => {
        let decodedJson = payload.DecodedJson;
        let hex = `${decodedJson.OptionsByte.Hex}${decodedJson.MobileIDLength.Hex}${decodedJson.MobileID.Hex}${decodedJson.MobileIDTypeLength.Hex}${decodedJson.MobileIDType.Hex}0201${decodedJson.SequenceNo.Hex}${decodedJson.MessageType.Hex}0000000000`;
        return hex;
    }
}

let dbColumns = (payload) => {
    if (payload == null)
        return null;

    let { MobileID, Longitude, Latitude, SequenceNo, Speed, HDOP, Altitude, UpdateTime, Inputs } = payload;
    return {
        IMEI: MobileID.Decoded,
        Longitude: Longitude.Decoded,
        Latitude: Latitude.Decoded,
        Altitude: Altitude.Decoded,
        SequenceNo: SequenceNo.Decoded,
        Speed: Speed.Decoded,
        Hdop: HDOP.Decoded,
        UpdateTime: UpdateTime.Decoded,
        OdometerKM: 0,
        Ignition: Inputs.Decoded == "IgnitionOn" ? true : false
    }
}

let convertToDataObj = (obj) => {
    if (Array.isArray(obj) == false) { // if object
        obj = cleanValue(obj);
    }
    else { // if Array
        let bin = '';
        _map(obj, (i) => {
            bin += cleanValue(i);
        });
        obj = bin;
    }

    return {
        Binary: obj,
        Hex: binaryToHex(obj),
        Decimal: binaryToDecimal(obj)
    };
}

let cleanValue = (bit) => { return replaceAll(jsonToString(bit), ",", "") };
let jsonToString = (bitArr) => { return bitArr.toJSON().toString(); };
let fieldsObj =
    {
        OptionsByte: null,
        MobileIDLength: null,
        MobileID: null,
        MobileIDTypeLength: null,
        MobileIDType: null,
        AuthenticationLength: null,
        Authentication: null,
        RoutingLength: null,
        Routing: null,
        ForwardingLength: null,
        Forwarding: null,
        ResponseRedirectionLength: null,
        ResponseRedirection: null,
        ServiceType: null,
        MessageType: null,
        SequenceNo: null,
        UpdateTime: null,
        TimeOfFix: null,
        Latitude: null,
        Longitude: null,
        Altitude: null,
        Speed: null,
        Heading: null,
        Satellites: null,
        FixStatus: null,
        Carrier: null,
        RSSI: null,
        CommState: null,
        HDOP: null,
        Inputs: null,
        UnitStatus: null,
        EventIndex: null,
        EventCode: null,
        AccumCount: null,
        Spare: null
    };