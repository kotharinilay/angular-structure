import { replaceAll } from './lib/utility';
var base64url = require('base64url');
import jwt from 'jsonwebtoken';
//import { hasPermission } from './workflows/server-protocol';

module.exports = {
    headers: (req, res, next) => {
        // Add CORS on ExpressJS        
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    },
    auth: (req, res, next) => {
        // Verify JWT Token        
        const token = extractToken(req.headers['authorization']);
        jwt.verify(token, process.env.TOKEN_SECRET, (err, data) => {
            if (err)
                return res.status(401).send(err);

            // hasPermission().then(() => {
            //     next();
            // }).catch((err) => {
            //     return res.status(500).send(err);
            // });
        });
    }
}

let extractToken = (auth) => {
    if (auth) {
        return replaceAll(auth, 'Bearer', '');
    }
    return null;
}