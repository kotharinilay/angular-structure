
require('./../env');
var SequelizeAuto = require('sequelize-auto');

var config = {
    dialectOptions: {
        instanceName: process.env.DB_SERVER_INSTANCE,   // server instance
        port: process.env.DB_PORT                       // server running port (default:1433)
    }
};

var opt = {
    host: process.env.DB_HOST,                          // server host
    dialect: 'mssql',
    port: process.env.DB_PORT,                          // server running port
    config: config,
    additional: {
        timestamps: false
    },
    directory: 'app/db/models'                        // output directory
};

var auto = new SequelizeAuto(
    process.env.DB_CATALOG,                             // database name
    process.env.DB_USER,                                // db user
    process.env.DB_PASSWORD,                            // db password
opt);

auto.run(function (err) {
    if (err) throw err;

    console.log(auto.tables); // table list
    console.log(auto.foreignKeys); // foreign key list
});
