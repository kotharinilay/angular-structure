var alias = {
    hardware: '/hardware',
    pm2: '/process'
};

const endPoint = {
    hardware: {
        FetchAllProfilesFromDb: '/profiles/fetchall'        // fetch all hardware profiles in the database
    },
    pm2: {
        StartSpecificServer: alias.pm2 + '/start',          // listen specific port with protocal
        StartAllServers: alias.pm2 + '/startall',           // listen all ports from database
        StopSpecificServer: alias.pm2 + '/stop',            // stop listening specific port
        StopAllServers: alias.pm2 + '/stopall',             // stop listening all ports
        RemoveSpecificServer: alias.pm2 + '/remove',        // remove port from pm2 process 
        RemoveAllServers: alias.pm2 + '/removeall',         // remove all ports from pm2 process
        RestartSpecificServer: alias.pm2 + '/restart',      // restart specific port 
        RestartAllServers: alias.pm2 + '/restartall'        // restart all ports
    }
}

module.exports = endPoint;