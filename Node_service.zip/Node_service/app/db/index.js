'use strict';

/**************************************
 * expose database models and sequelize instance from here
 * should be instantiate as singleton
 * ***********************************/

// load required modules
var Sequelize = require('sequelize');
var fs = require('fs');
var path = require('path');

// local variables
var db = { models: [] };

// create new connection object 
var sequelize = new Sequelize(
    process.env.DB_CATALOG,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
        logging: true,
        host: process.env.DB_HOST,
        dialect: 'mssql',
        port: process.env.DB_PORT,
        //query: { raw: true },
        dialectOptions: {
            connectTimeout: 10000,
            instanceName: process.env.DB_SERVER_INSTANCE,
            multipleStatements: true
        },
        define:
        {
            timestamps: false // disabled timestamp to ignore createdAt, updatedAt fields 
        },
        pool: {
            min: 1,
            max: 10,
            acquire:  10000,
          },
    });

// load entity files from model folder & map with database tables
var models = path.join(process.cwd(), '/app/db/models');
fs
    .readdirSync(models)
    .filter(function (file) {
        return (file.indexOf('.') !== 0);
    })
    .forEach(function (file) {
        var model = sequelize.import(path.join(models, file));
        db[model.name] = model;
        db.models.push(model.name);
    });

Object
    .keys(db)
    .forEach(function (model) {
        if ('associate' in db[model]) {
            db[model].associate(db);
        }
    });

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// perform selection queries
db.Query = (sql) => {
    return db.sequelize.query(sql, { type: db.Sequelize.QueryTypes.SELECT }).then(function (result) {      
        return result;
    }).catch(function (err) {        
        throw new Error(err);
    });
}

// perform DML queries
db.Exec = (sql, trans) => {        
    return db.sequelize.query(sql, { transaction: trans }).then(function (result) {        
        return result;
    }).catch(function (err) {        
        throw new Error(err);
    });
}

module.exports = db;