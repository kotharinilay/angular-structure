/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('ClientHardwareProfile', {
		ClientHardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareProfile',
				key: 'HardwareProfileId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'ClientHardwareProfile',
		timestamps: false
	});
};
