/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('HardwareParserFieldMapping', {
		HardwareParserFieldMappingId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		HardwareParserId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareParser',
				key: 'HardwareParserId'
			}
		},
		EventCodeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'EventCode',
				key: 'EventCodeId'
			}
		},
		CalampFieldId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'CalampField',
				key: 'CalampFieldId'
			}
		}
	}, {
		tableName: 'HardwareParserFieldMapping',
		timestamps: false
	});
};
