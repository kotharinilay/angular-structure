/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('HardwareParser', {
		HardwareParserId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ParserKey: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'HardwareParser',
		timestamps: false
	});
};
