/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('AuditLog', {
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		CreatedByUserId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		CreatedOnUTC: {
			type: DataTypes.DATE,
			allowNull: true,
			defaultValue: '(getutcdate())'
		},
		CreatedFromIPAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CreatedFromGPS: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LastUpdatedByUserId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		LastUpdatedOnUTC: {
			type: DataTypes.DATE,
			allowNull: true,
			defaultValue: '(getutcdate())'
		},
		LastUpdatedFromIPAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LastUpdatedFromGPS: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DeletedByUserId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		DeletedOnUTC: {
			type: DataTypes.DATE,
			allowNull: true,
			defaultValue: '(getutcdate())'
		},
		DeletedFromIPAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DeletedFromGPS: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'AuditLog',
		timestamps: false
	});
};
