/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('FileStorage', {
		FileStorageId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		DisplayFileName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		FileAccessUrl: {
			type: DataTypes.STRING,
			allowNull: false
		},
		MimeType: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'FileStorage',
		timestamps: false
	});
};
