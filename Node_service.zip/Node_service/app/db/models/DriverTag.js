/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DriverTag', {
		DriverTagId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		TagCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		}
	}, {
		tableName: 'DriverTag',
		timestamps: false
	});
};
