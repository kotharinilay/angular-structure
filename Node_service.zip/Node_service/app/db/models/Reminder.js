/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Reminder', {
		ReminderId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		RemindMeTo: {
			type: DataTypes.STRING,
			allowNull: false
		},
		DueDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		IsRepeat: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsVehicleReminder: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsRepeatOdometer: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		DueOdometer: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		RepeatOdometer: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		IsEnabled: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Reminder',
		timestamps: false
	});
};
