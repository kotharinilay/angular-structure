/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleColor', {
		VehicleColorId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ColorCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'VehicleColor',
		timestamps: false
	});
};
