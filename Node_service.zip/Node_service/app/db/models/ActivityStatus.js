/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('ActivityStatus', {
		ActivityStatusId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		ColorCode: {
			type: DataTypes.STRING,
			allowNull: false,
			defaultValue: '(N#000000'
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'ActivityStatus',
		timestamps: false
	});
};
