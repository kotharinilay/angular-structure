/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Asset', {
		AssetId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'ClientGroup',
				key: 'ClientGroupId'
			}
		},
		IsIndividual: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AssetTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'AssetType',
				key: 'AssetTypeId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Title: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Description: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Address: {
			type: DataTypes.STRING,
			allowNull: true
		},
		City: {
			type: DataTypes.STRING,
			allowNull: true
		},
		State: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Postcode: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		TimezoneId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Timezone',
				key: 'TimezoneId'
			}
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		PhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FaxNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		MobileNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Website: {
			type: DataTypes.STRING,
			allowNull: true
		},
		PagerNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactMethod: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		BatteryLevel: {
			type: DataTypes.STRING,
			allowNull: true
		},
		BatteryVoltage: {
			type: DataTypes.STRING,
			allowNull: true
		},
		BloodType: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LocaleDescription: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Lat: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Long: {
			type: DataTypes.STRING,
			allowNull: true
		},
		AssetPhotoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		MapIconId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MapIcon',
				key: 'MapIconId'
			}
		},
		TrackLineColor: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CurrentDeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Asset',
		timestamps: false
	});
};
