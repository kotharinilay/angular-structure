/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('PlaceAlertVehicle', {
		PlaceAlertVehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		PlaceAlertId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'PlaceAlert',
				key: 'PlaceAlertId'
			}
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		}
	}, {
		tableName: 'PlaceAlertVehicle',
		timestamps: false
	});
};
