/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Driver', {
		DriverId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'ClientGroup',
				key: 'ClientGroupId'
			}
		},
		FirstName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		LastName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Title: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DriverTagId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'DriverTag',
				key: 'DriverTagId'
			}
		},
		IntegrationId: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DriverColor: {
			type: DataTypes.STRING,
			allowNull: true
		},
		PersonalId: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Gender: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((0))'
		},
		BirthDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		Height: {
			type: DataTypes.STRING,
			allowNull: true
		},
		BloodType: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TRN: {
			type: DataTypes.STRING,
			allowNull: true
		},
		YearsOfExperience: {
			type: DataTypes.STRING,
			allowNull: true
		},
		MedicalExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		HireDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		PhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FaxNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		MobileNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Pager: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactMethod: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		Address: {
			type: DataTypes.STRING,
			allowNull: true
		},
		City: {
			type: DataTypes.STRING,
			allowNull: true
		},
		State: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Postcode: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		EmergencyContactName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmergencyContactPhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmergencyContactName2: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmergencyContactPhoneNumber2: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmergencyContactName3: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmergencyContactPhoneNumber3: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LicenseNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LicenseState: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LicenseRestriction: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LicenseExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		InsuarancePolicy: {
			type: DataTypes.STRING,
			allowNull: true
		},
		InsuaranceCompany: {
			type: DataTypes.STRING,
			allowNull: true
		},
		InsuaranceExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		DriverPhotoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Driver',
		timestamps: false
	});
};
