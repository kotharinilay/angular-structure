/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('People', {
		PeopleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		FirstName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		LastName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		LicenseNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsLicenseExpiryReminderEnabled: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		LicenseExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		PhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		SecurityRoleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'SecurityRole',
				key: 'SecurityRoleId'
			}
		},
		CanLogin: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		Username: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Salt: {
			type: DataTypes.STRING,
			allowNull: true
		},
		PasswordHash: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LastLoginDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		FailedAttempt: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((0))'
		},
		IsLocked: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		LockedDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		ForcePasswordReset: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		DefaultUrl: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsClientAdmin: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsActive: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		PhotoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		DriverTagId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'DriverTag',
				key: 'DriverTagId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'People',
		timestamps: false
	});
};
