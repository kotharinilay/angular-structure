/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Permission', {
		PermissionId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		IsAustracker: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		}
	}, {
		tableName: 'Permission',
		timestamps: false
	});
};
