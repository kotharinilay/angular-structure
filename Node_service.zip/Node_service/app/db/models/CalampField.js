/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('CalampField', {
		CalampFieldId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		FieldKey: {
			type: DataTypes.STRING,
			allowNull: false
		},
		DisplayName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		DataType: {
			type: DataTypes.STRING,
			allowNull: false,
			defaultValue: 'string'
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'CalampField',
		timestamps: false
	});
};
