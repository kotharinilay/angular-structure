/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('SecurityRole', {
		SecurityRoleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		BaseClientRoleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'BaseClientRole',
				key: 'BaseClientRoleId'
			}
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		IsAustracker: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsActive: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'SecurityRole',
		timestamps: false
	});
};
