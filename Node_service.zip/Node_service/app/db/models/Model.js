/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Model', {
		ModelId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		ManufacturerId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Manufacturer',
				key: 'ManufacturerId'
			}
		},
		ModelTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'ModelType',
				key: 'ModelTypeId'
			}
		},
		ProductURL: {
			type: DataTypes.STRING,
			allowNull: true
		},
		GatewayName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		GatewayPassword: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ImageId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Model',
		timestamps: false
	});
};
