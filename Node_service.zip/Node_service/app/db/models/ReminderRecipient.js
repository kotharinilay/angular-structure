/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('ReminderRecipient', {
		ReminderRecipientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ReminderId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Reminder',
				key: 'ReminderId'
			}
		},
		PeopleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'ReminderRecipient',
		timestamps: false
	});
};
