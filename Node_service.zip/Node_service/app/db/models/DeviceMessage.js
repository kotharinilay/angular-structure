/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DeviceMessage', {
		DeviceMessageId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		MessageId: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		VehicleTripId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'VehicleTrip',
				key: 'VehicleTripId'
			}
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		AssetId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Asset',
				key: 'AssetId'
			}
		},
		DeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareProfile',
				key: 'HardwareProfileId'
			}
		},
		HardwareParserId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareParser',
				key: 'HardwareParserId'
			}
		},
		MessageReceivedUTC: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: '(getutcdate())'
		},
		UpdateTimeUTC: {
			type: DataTypes.DATE,
			allowNull: true
		},
		MessageString: {
			type: DataTypes.STRING,
			allowNull: true
		},
		BinaryData: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CurrentPlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Place',
				key: 'PlaceId'
			}
		},
		CurrentGeoLocation: {
			type: DataTypes.STRING,
			allowNull: false
		},
		CurrentPlaceName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Altitude: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LocationDistance: {
			type: DataTypes.DECIMAL,
			allowNull: false,
			defaultValue: '((0))'
		},
		Speed: {
			type: DataTypes.DECIMAL,
			allowNull: false
		},
		Hdop: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		Ignition: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		}
	}, {
		tableName: 'DeviceMessage',
		timestamps: false
	});
};
