/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('SecurityRolePermission', {
		SecurityRolePermissionId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SecurityRoleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'SecurityRole',
				key: 'SecurityRoleId'
			}
		},
		PermissionId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Permission',
				key: 'PermissionId'
			}
		},
		PrivilegeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Privilege',
				key: 'PrivilegeId'
			}
		}
	}, {
		tableName: 'SecurityRolePermission',
		timestamps: false
	});
};
