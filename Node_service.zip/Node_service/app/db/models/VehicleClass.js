/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleClass', {
		VehicleClassId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'VehicleClass',
		timestamps: false
	});
};
