/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Manufacturer', {
		ManufacturerId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		PhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Website: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Manufacturer',
		timestamps: false
	});
};
