/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('AnnouncementReceiver', {
		AnnouncementReceiverId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		AnnouncementId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Announcement',
				key: 'AnnouncementId'
			}
		},
		ReceiverId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		}
	}, {
		tableName: 'AnnouncementReceiver',
		timestamps: false
	});
};
