/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('EntityType', {
		EntityTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		EntityType: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'EntityType',
		timestamps: false
	});
};
