/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('FuelType', {
		FuelTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'FuelType',
		timestamps: false
	});
};
