/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('MenuItem', {
		MenuItemId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true,
			references: {
				model: 'MenuItem',
				key: 'MenuItemId'
			}
		},
		ModuleMenuId: {
			type: DataTypes.UUIDV4,
			allowNull: true
		},
		DisplayName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		PermissionName: {
			type: DataTypes.STRING,
			allowNull: false
		},
		IsActive: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		}
	}, {
		tableName: 'MenuItem',
		timestamps: false
	});
};
