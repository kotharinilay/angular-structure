/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('PlaceAlertRecipient', {
		PlaceAlertRecipientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		PlaceAlertId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'PlaceAlert',
				key: 'PlaceAlertId'
			}
		},
		PeopleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'PlaceAlertRecipient',
		timestamps: false
	});
};
