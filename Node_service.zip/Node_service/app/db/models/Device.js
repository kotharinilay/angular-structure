/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Device', {
		DeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		IMEI: {
			type: DataTypes.STRING,
			allowNull: false
		},
		ModelId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Model',
				key: 'ModelId'
			}
		},
		PurchaseDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		Condition: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((1))'
		},
		RMACode: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DeviceKey: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Script: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ReportingFrequency: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		InventorySKU: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Firmware: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CarrierId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Carrier',
				key: 'CarrierId'
			}
		},
		ServicePlanId: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'ClientGroup',
				key: 'ClientGroupId'
			}
		},
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'HardwareProfile',
				key: 'HardwareProfileId'
			}
		},
		IsEnabled: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Device',
		timestamps: false
	});
};
