/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleTankDetail', {
		VehicleTankId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false
		},
		TankNo: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		FlowRate: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FuelCapacity: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FuelLevel: {
			type: DataTypes.STRING,
			allowNull: true
		},
		MinFuelVoltage: {
			type: DataTypes.STRING,
			allowNull: true
		},
		MaxFuelVoltage: {
			type: DataTypes.STRING,
			allowNull: true
		},
		SensorHeight: {
			type: DataTypes.STRING,
			allowNull: true
		},
		SpringHeight: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Circumference: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TankLength: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'VehicleTankDetail',
		timestamps: false
	});
};
