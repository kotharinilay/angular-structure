/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('HardwareProfile', {
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		HardwareParserId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareParser',
				key: 'HardwareParserId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Protocol: {
			type: DataTypes.STRING,
			allowNull: false
		},
		PortNumber: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		Description: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Firmware: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ImagePath: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TravelDistance: {
			type: DataTypes.STRING,
			allowNull: true
		},
		StopSpeedThreshold: {
			type: DataTypes.STRING,
			allowNull: true
		},
		HasPingSupport: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		PingMessage: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'HardwareProfile',
		timestamps: false
	});
};
