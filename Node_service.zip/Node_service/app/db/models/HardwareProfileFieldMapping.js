/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('HardwareProfileFieldMapping', {
		HardwareProfileFieldMappingId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true,
			references: {
				model: 'HardwareProfileFieldMapping',
				key: 'HardwareProfileFieldMappingId'
			}
		},
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareProfile',
				key: 'HardwareProfileId'
			}
		},
		EventCodeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'EventCode',
				key: 'EventCodeId'
			}
		},
		CalampFieldId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'CalampField',
				key: 'CalampFieldId'
			}
		}
	}, {
		tableName: 'HardwareProfileFieldMapping',
		timestamps: false
	});
};
