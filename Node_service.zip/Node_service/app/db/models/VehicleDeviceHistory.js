/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleDeviceHistory', {
		VehicleDeviceHistoryId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		DeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		AssignmentDate: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: '(getutcdate())'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'VehicleDeviceHistory',
		timestamps: false
	});
};
