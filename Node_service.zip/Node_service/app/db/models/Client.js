/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Client', {
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		ClientTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'ClientType',
				key: 'ClientTypeId'
			}
		},
		FirstName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		LastName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Address: {
			type: DataTypes.STRING,
			allowNull: true
		},
		City: {
			type: DataTypes.STRING,
			allowNull: true
		},
		State: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Postcode: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		Website: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EmailAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		PhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FaxNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ActivationDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		ActivationDateUTC: {
			type: DataTypes.DATE,
			allowNull: true
		},
		DeactivationDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		DeactivationDateUTC: {
			type: DataTypes.DATE,
			allowNull: true
		},
		IsAustracker: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsDemoClient: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		MaxUser: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((20))'
		},
		MaxGeofence: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((10000))'
		},
		MaxGroup: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((10))'
		},
		MaxAsset: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((10))'
		},
		MaxIndividual: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((10))'
		},
		MaxVehicle: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((10))'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		},
		LogoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		}
	}, {
		tableName: 'Client',
		timestamps: false
	});
};
