/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleOtherDetail', {
		VehicleDetailId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		FuelTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FuelType',
				key: 'FuelTypeId'
			}
		},
		FuelEconomy: {
			type: "NCHAR",
			allowNull: true
		},
		FuelCost: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FuelConsumption: {
			type: DataTypes.STRING,
			allowNull: true
		},
		RoadSideAssistance: {
			type: DataTypes.STRING,
			allowNull: true
		},
		RoadSideAssistancePhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		InsuaranceCompany: {
			type: DataTypes.STRING,
			allowNull: true
		},
		InsuarancePolicy: {
			type: DataTypes.STRING,
			allowNull: true
		},
		AcquiredDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		InsuaranceExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		Tag: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TagState: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TagIssuedDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		TagExpiryDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		VehicleClassId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'VehicleClass',
				key: 'VehicleClassId'
			}
		},
		EquipmentNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EquipmentLicense: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EquipmentState: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EquipmentCountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		EquipmentPrice: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		IsEquipmentOnLease: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		CargoSeats: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CargoTowCapacity: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CargoGrossVehicleWeightRating: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CargoPassengerNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CargoPayload: {
			type: DataTypes.STRING,
			allowNull: true
		},
		GrantNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		GranteeName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		GrantActivityNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CustomDefined1: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CustomDefined2: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CustomDefined3: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CustomDefined4: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CustomDefined5: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'VehicleOtherDetail',
		timestamps: false
	});
};
