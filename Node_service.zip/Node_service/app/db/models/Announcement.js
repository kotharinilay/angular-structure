/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Announcement', {
		AnnouncementId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SenderId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'People',
				key: 'PeopleId'
			}
		},
		SentDate: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: '(getutcdate())'
		},
		ExpiryDate: {
			type: DataTypes.DATE,
			allowNull: false
		},
		Message: {
			type: DataTypes.STRING,
			allowNull: false
		},
		MessageText: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'Announcement',
		timestamps: false
	});
};
