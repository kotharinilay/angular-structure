/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('EventCode', {
		EventCodeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		EventIndex: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		EventDisplayName: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'EventCode',
		timestamps: false
	});
};
