/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('FuelSystemType', {
		FuelSystemTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'FuelSystemType',
		timestamps: false
	});
};
