/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Place', {
		PlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SquareMeterArea: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		HasCircularGeofence: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		GeofenceCoordinates: {
			type: DataTypes.STRING,
			allowNull: true
		},
		CenterCoordinate: {
			type: DataTypes.STRING,
			allowNull: true
		},
		NumberOfVisit: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((0))'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Place',
		timestamps: false
	});
};
