/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Vehicle', {
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'ClientGroup',
				key: 'ClientGroupId'
			}
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		VIN: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Rego: {
			type: DataTypes.STRING,
			allowNull: true
		},
		VehicleTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'EntityType',
				key: 'EntityTypeId'
			}
		},
		Description: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Year: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Make: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Model: {
			type: DataTypes.STRING,
			allowNull: true
		},
		HistoryColor: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TotalOdometerKM: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		IdleEconomy: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TotalEngineHours: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		Engine: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EngineType: {
			type: DataTypes.STRING,
			allowNull: true
		},
		EngineBrand: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Transmission: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: '((0))'
		},
		Temperature: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Temperature2: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FuelSystemTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true
		},
		BatteryLevel: {
			type: DataTypes.STRING,
			allowNull: true
		},
		BatteryVoltage: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IgnitionStatus: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		VehiclePhotoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		DefaultDriverId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Driver',
				key: 'DriverId'
			}
		},
		CurrentDeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		MapIconId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MapIcon',
				key: 'MapIconId'
			}
		},
		TrackLineColor: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsPrivateTrip: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsTripTypeSwitched: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'Vehicle',
		timestamps: false
	});
};
