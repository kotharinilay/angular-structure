/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('BaseClientRolePermission', {
		BaseClientRolePermissionId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		BaseClientRoleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'BaseClientRole',
				key: 'BaseClientRoleId'
			}
		},
		PermissionId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Permission',
				key: 'PermissionId'
			}
		},
		PrivilegeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Privilege',
				key: 'PrivilegeId'
			}
		}
	}, {
		tableName: 'BaseClientRolePermission',
		timestamps: false
	});
};
