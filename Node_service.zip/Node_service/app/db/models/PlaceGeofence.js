/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('PlaceGeofence', {
		PlaceGeofenceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		PlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Place',
				key: 'PlaceId'
			}
		},
		Coordinate: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SortOrder: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: '((1))'
		}
	}, {
		tableName: 'PlaceGeofence',
		timestamps: false
	});
};
