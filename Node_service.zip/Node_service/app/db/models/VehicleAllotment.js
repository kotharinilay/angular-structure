/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleAllotment', {
		VehicleAllotmentId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		DriverId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Driver',
				key: 'DriverId'
			}
		},
		AllotmentDate: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: '(getutcdate())'
		},
		AllottedBy: {
			type: DataTypes.UUIDV4,
			allowNull: true
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'VehicleAllotment',
		timestamps: false
	});
};
