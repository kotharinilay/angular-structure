/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('HardwareProfileIOString', {
		HardwareProfileIOStringId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		HardwareProfileId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'HardwareProfile',
				key: 'HardwareProfileId'
			}
		},
		IOCode: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		IOValue: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'HardwareProfileIOString',
		timestamps: false
	});
};
