/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DeviceMessagePayload', {
		DeviceMessagePayloadId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		DeviceMessageId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'DeviceMessage',
				key: 'DeviceMessageId'
			}
		},
		EventCodeId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'EventCode',
				key: 'EventCodeId'
			}
		},
		CalampFieldId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'CalampField',
				key: 'CalampFieldId'
			}
		},
		FieldValue: {
			type: DataTypes.STRING,
			allowNull: true
		}
	}, {
		tableName: 'DeviceMessagePayload',
		timestamps: false
	});
};
