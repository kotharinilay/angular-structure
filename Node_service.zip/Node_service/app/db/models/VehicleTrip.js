/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleTrip', {
		VehicleTripId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'ClientGroup',
				key: 'ClientGroupId'
			}
		},
		DriverId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Driver',
				key: 'DriverId'
			}
		},
		FromPlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Place',
				key: 'PlaceId'
			}
		},
		FromGeoLocation: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FromPlaceName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DestinationPlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Place',
				key: 'PlaceId'
			}
		},
		DestinationGeoLocation: {
			type: DataTypes.STRING,
			allowNull: true
		},
		DestinationPlaceName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		JourneyStartDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		JourneyEndDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		JourneyDuration: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		JourneyDistance: {
			type: DataTypes.DECIMAL,
			allowNull: true
		},
		IsPrivateTrip: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		}
	}, {
		tableName: 'VehicleTrip',
		timestamps: false
	});
};
