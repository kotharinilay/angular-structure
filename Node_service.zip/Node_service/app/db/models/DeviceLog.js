/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DeviceLog', {
		DeviceLogId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		Protocol: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Message: {
			type: DataTypes.STRING,
			allowNull: false
		},
		RemoteIp: {
			type: DataTypes.STRING,
			allowNull: false
		},
		RemotePort: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		TargetIp: {
			type: DataTypes.STRING,
			allowNull: false
		},
		TargetPort: {
			type: DataTypes.INTEGER,
			allowNull: false
		},
		ReceivedAtUTC: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		tableName: 'DeviceLog',
		timestamps: false
	});
};
