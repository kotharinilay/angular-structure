/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DeviceCommand', {
		DeviceCommandId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		AssetId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Asset',
				key: 'AssetId'
			}
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		DeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		CommandId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Command',
				key: 'CommandId'
			}
		},
		Body: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Status: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '((0))'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'DeviceCommand',
		timestamps: false
	});
};
