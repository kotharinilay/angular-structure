/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('AssetDeviceHistory', {
		AssetDeviceHistoryId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		AssetId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Asset',
				key: 'AssetId'
			}
		},
		DeviceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Device',
				key: 'DeviceId'
			}
		},
		AssignmentDate: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: '(getutcdate())'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'AssetDeviceHistory',
		timestamps: false
	});
};
