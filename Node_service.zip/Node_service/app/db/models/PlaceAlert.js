/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('PlaceAlert', {
		PlaceAlertId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		PlaceId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Place',
				key: 'PlaceId'
			}
		},
		GenerateOnEntry: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		GenerateOnExit: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		IsTemporary: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		TempStartDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		TempEndDate: {
			type: DataTypes.DATE,
			allowNull: true
		},
		GenerateOnDays: {
			type: DataTypes.STRING,
			allowNull: true
		},
		FromTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		ToTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		IsEnabled: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'PlaceAlert',
		timestamps: false
	});
};
