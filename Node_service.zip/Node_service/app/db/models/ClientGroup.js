/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('ClientGroup', {
		ClientGroupId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		ClientId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Client',
				key: 'ClientId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		SupervisorName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		Description: {
			type: DataTypes.STRING,
			allowNull: true
		},
		TimezoneId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Timezone',
				key: 'TimezoneId'
			}
		},
		TerritoryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Territory',
				key: 'TerritoryId'
			}
		},
		MeasurementUnitId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MeasurementUnit',
				key: 'MeasurementUnitId'
			}
		},
		VolumeUnitId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MeasurementUnit',
				key: 'MeasurementUnitId'
			}
		},
		TemperatureUnitId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MeasurementUnit',
				key: 'MeasurementUnitId'
			}
		},
		CountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		HasDayLightSavingTime: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '1'
		},
		SunriseTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		SunsetTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		OperationStartTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		OperationEndTime: {
			type: DataTypes.TIME,
			allowNull: true
		},
		TrackWorkingHoursOnly: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		ContactFirstName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactLastName: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactCity: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactState: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactPostcode: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactCountryId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'Country',
				key: 'CountryId'
			}
		},
		ContactEmailAddress: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactPrimaryPhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		ContactSecondaryPhoneNumber: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		PhotoId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'FileStorage',
				key: 'FileStorageId'
			}
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'ClientGroup',
		timestamps: false
	});
};
