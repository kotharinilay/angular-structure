/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('Carrier', {
		CarrierId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'Carrier',
		timestamps: false
	});
};
