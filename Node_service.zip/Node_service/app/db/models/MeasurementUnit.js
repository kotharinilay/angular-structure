/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('MeasurementUnit', {
		MeasurementUnitId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		MeasurementTypeId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'MeasurementType',
				key: 'MeasurementTypeId'
			}
		},
		SystemCode: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		}
	}, {
		tableName: 'MeasurementUnit',
		timestamps: false
	});
};
