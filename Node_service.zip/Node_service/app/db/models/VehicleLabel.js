/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('VehicleLabel', {
		VehicleLabelId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		VehicleId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Vehicle',
				key: 'VehicleId'
			}
		},
		Name: {
			type: DataTypes.STRING,
			allowNull: false
		},
		VehicleColorId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'VehicleColor',
				key: 'VehicleColorId'
			}
		}
	}, {
		tableName: 'VehicleLabel',
		timestamps: false
	});
};
