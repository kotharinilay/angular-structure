/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('DriverNote', {
		DriverNoteId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			primaryKey: true
		},
		DriverId: {
			type: DataTypes.UUIDV4,
			allowNull: false,
			references: {
				model: 'Driver',
				key: 'DriverId'
			}
		},
		Subject: {
			type: DataTypes.STRING,
			allowNull: false
		},
		Note: {
			type: DataTypes.STRING,
			allowNull: true
		},
		IsDeleted: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: '0'
		},
		AuditLogId: {
			type: DataTypes.UUIDV4,
			allowNull: true,
			references: {
				model: 'AuditLog',
				key: 'AuditLogId'
			}
		}
	}, {
		tableName: 'DriverNote',
		timestamps: false
	});
};
