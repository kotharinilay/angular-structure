'use strict';

/*********************************************************
* Client side config variables
*********************************************************/

module.exports = {
    RECAPTCHA_KEY: "6Lc_KBAUAAAAAASiL4wk_ScO-WXSN3d2SpcFJfkl",
    GOOGLE_MAP_URL: "https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places",
    MAP_API_KEY: "AIzaSyDxX3Ok-zn07ZAQiqrgjO0AJAhGHQNrNF4",
    SITE_URL: ""
}