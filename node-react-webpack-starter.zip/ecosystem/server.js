'use strict';

/*********************************************************
 * Server side environment variables
 * http://pm2.keymetrics.io/docs/usage/application-declaration/
 *********************************************************/
var ip = require("ip");
const address = ip.address();

module.exports = {
    apps: [{
            name: "development",
            script: "src/server/development.js",
            env: {
                NODE_ENV: "development",
                SITE_URL: `http://${address}:5000`, // Do not write '/' at the end of url
                PORT: '5000',
                // Database
                DB_HOST: "localhost",
                DB_HOST_USERNAME: "root",
                DB_HOST_PASSWORD: "Nk@12345",
                DB_PORT: "3306",
                DB_NAME: "react-demo",
                DB_DIALECT: "mariadb",
                // // AWS Credentials
                // AWS_ACCESS_KEY: "AKIAISARQPKIIRYVBMZA",
                // AWS_SECRET_ACCESS_KEY: "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",
                // AWS_REGION: "ap-southeast-2",
                // AWS_ACCOUNT: "027433987909",
                // // Smtp
                // SMTP_HOST: 'smtp.office365.com',
                // SMTP_PORT: 587,
                // SMTP_SECURE: false,
                // SMTP_AUTH_USER: 'kothari_nilay@yahoo.co.in',
                // SMTP_AUTH_PASS: 'Nilay01',
                // // Email
                // NO_REPLY_EMAIL: 'no-reply@yahoo.com',
                // ADMIN_EMAIL: 'kothari_nilay@yahoo.co.in',
                // SECRET_KEY: 'AKIAIU7XQJPTGLH6SW2A', // For encryption decryption url
                // Firebase
                FIREBASE_API_KEY: "AIzaSyBcyGOzrpQLvhzmHs2petlwI5a8x0jTN7Y",
                FIREBASE_AUTH_DOMAIN: "react-demo-fda5c.firebaseio.com",
                FIREBASE_DATABASE_URL: "https://react-demo-fda5c.firebaseio.com",
                FIREBASE_STORAGE_BUCKET: "react-demo-fda5c.appspot.com",
                FIREBASE_MESSAGING_SENDER_ID: "306531023973",
                FIREBASE_AUTH_USERNAME: "kothari_nilay@yahoo.co.in",
                FIREBASE_AUTH_PASSWORD: "Nk@12345",
                // token auth
                AUTH_SECRET_KEY: 'Nk@12345',
                AUTH_TOKEN_EXP: '7d',
                // //S3 variables
                // BUCKET_NAME: 'Demo',
                // ACL: 'public-read',
                // redis config
                REDIS_HOST: 'localhost',
                REDIS_PORT: 6379,
                REDIS_EXPIRY_TIME: 604800 // seconds
            }
        },
        {
            name: "production",
            script: "src/server/production.js",
            env: {
                NODE_ENV: "production",
                SITE_URL: 'http://localhost:3000', // Do not write '/' at the end of url
                PORT: '3000',
                // Database
                DB_HOST: "localhost",
                DB_HOST_USERNAME: "root",
                DB_HOST_PASSWORD: "Nk@12345",
                DB_PORT: "3306",
                DB_NAME: "react-demo",
                DB_DIALECT: "mariadb",
                // // AWS Credentials
                // AWS_ACCESS_KEY: "AKIAISARQPKIIRYVBMZA",
                // AWS_SECRET_ACCESS_KEY: "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",
                // AWS_REGION: "ap-southeast-2",
                // AWS_ACCOUNT: "027433987909",
                // // Smtp
                // SMTP_HOST: 'zealousys.local',
                // SMTP_PORT: 25,
                // SMTP_SECURE: false,
                // SMTP_AUTH_USER: 'jayk.patel@zealousys.local',
                // SMTP_AUTH_PASS: 'ze@lous2012',
                // // Email
                // NO_REPLY_EMAIL: 'jayk.patel@zealousys.local',
                // ADMIN_EMAIL: 'jayk.patel@zealousys.local',
                // SECRET_KEY: 'AKIAIU7XQJPTGLH6SW2A', // For encryption decryption url
                // Firebase
                FIREBASE_API_KEY: "AIzaSyBcyGOzrpQLvhzmHs2petlwI5a8x0jTN7Y",
                FIREBASE_AUTH_DOMAIN: "react-demo-fda5c.firebaseio.com",
                FIREBASE_DATABASE_URL: "https://react-demo-fda5c.firebaseio.com",
                FIREBASE_STORAGE_BUCKET: "react-demo-fda5c.appspot.com",
                FIREBASE_MESSAGING_SENDER_ID: "306531023973",
                FIREBASE_AUTH_USERNAME: "kothari_nilay@yahoo.co.in",
                FIREBASE_AUTH_PASSWORD: "Nk@12345",
                // token auth
                AUTH_SECRET_KEY: 'Nk@12345',
                AUTH_TOKEN_EXP: '7d',
                // //S3 variables
                // BUCKET_NAME: 'Demo',
                // ACL: 'public-read',
                // redis config
                REDIS_HOST: 'localhost',
                REDIS_PORT: 6379,
                REDIS_EXPIRY_TIME: 604800 // seconds
            }
        }
    ]
};