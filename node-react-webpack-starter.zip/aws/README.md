This repo consist all stuff related to Amazon Web Services. All services are defined in the respective folder.
