This repo consist common utility which can be rendered at server/client both (universal).
 
- Moment-Timezone
- Numeral
- Validator
- Guid/UUID