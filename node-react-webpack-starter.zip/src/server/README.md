All server side stuff will be placed here 

- Server instance
- Api routes
- Middlewares
- Authentication & Authorization
- Business Logic
- Custom viewmodels for business logic
