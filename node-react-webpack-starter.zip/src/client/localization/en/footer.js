'use strict';

/*************************************
 * Footer component
 * *************************************/

module.exports = {
        PRIVACY_POLICY: 'Privacy Policy',
        LICENSE_AGREEMENT: 'End User License Agreement',
        HELP: 'Help',
        CONTACT_US: 'Contact us',
        COPYRIGHT: 'Copyright',
        COPYRIGHT_AGLIVE: '2017 Aglive Pty Ltd',
        VERSION: 'version',
        CONTACTUS_POPUP: require('./popup-contactus')
};