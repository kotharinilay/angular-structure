'use strict';

/*************************************
 * Core components text
 * *************************************/

module.exports = {
        
};