
module.exports = {
    CONFIRMATION_POPUP_COMPONENT: require('./popup-confirmation')
};