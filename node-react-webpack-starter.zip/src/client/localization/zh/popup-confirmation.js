'use strict';

/*************************************
 * confirmation popup default values
 * *************************************/

module.exports = {
    TITLE: "确认",
    DEFAULT_TEXT: '你确定？',
    DEFAULT_CONFIRM_BUTTON_LABEL: '是',
    DEFAULT_CANCEL_BUTTON_LABEL: '没有'
};