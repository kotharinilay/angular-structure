'use strict';

/*************************************
 * Side naviagation bar consisting sub menus
 * *************************************/

module.exports = {
    SETUP_LABEL: '建立'
};