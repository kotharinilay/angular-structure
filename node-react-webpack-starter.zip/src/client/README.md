This repo consist browser web app with React, Redux, Core components, Wrapper components, Api services etc 

# server validation last count : 1110

Tooltip (react-portal-tooltip) : https://www.npmjs.com/package/react-portal-tooltip