'use strict';

/*************************************
 * container component - breed feature  
 * *************************************/

