'use strict';

/*********************************************
 * define action types overhere  
 * **********************************/

export const FORGOTPASSWORD_FORM_SET_VALUE = "FORGOTPASSWORD_FORM_SET_VALUE";