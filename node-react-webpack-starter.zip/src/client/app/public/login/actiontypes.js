'use strict';

/*******************************************
 * action names
 * ****************************************** */

export const SET_USER_INFO = "SETUSERINFO";