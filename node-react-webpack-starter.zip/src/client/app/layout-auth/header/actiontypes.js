'use strict';

/**************************
 * action types of header
 * **************************** */

export const SEARCHKEY = "SEARCHKEY"