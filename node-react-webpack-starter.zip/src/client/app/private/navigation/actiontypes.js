'use strict';

/**************************
 * action types of navigation
 * **************************** */
