'use strict';

/**************************
 * action list of navigation
 * **************************** */
