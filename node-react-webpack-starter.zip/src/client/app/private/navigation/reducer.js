'use strict';

/**************************
 * Perform the actions of navigation.
 * Return the state based on previous and current actions
 * **************************** */
