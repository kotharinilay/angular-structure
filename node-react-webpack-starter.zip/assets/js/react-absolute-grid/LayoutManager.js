'use strict';

/****************************************************
 * Adjusts layout width, internal margin, each child
 * components width as and when dragging performed
 * ************************************************/

export default class LayoutManager {

  columns;
  horizontalMargin;
  verticalMargin;
  layoutWidth;
  itemHeight;
  itemWidth;
  rowHeight;

  constructor(options, width){
    this.update(options, width);
  }

  update(options, width){

    //Calculates layout
    this.layoutWidth = width;
    this.zoom = options.zoom;
    this.itemWidth = Math.round(options.itemWidth * this.zoom);
    this.itemHeight = Math.round(options.itemHeight * this.zoom);
    this.columns = Math.floor(this.layoutWidth / this.itemWidth);
    this.horizontalMargin = 0;
    this.verticalMargin = (options.verticalMargin === -1) ? this.horizontalMargin : options.verticalMargin;
    this.rowHeight = this.itemHeight + this.verticalMargin;
  }

  getTotalHeight(filteredTotal){
    return (Math.ceil(filteredTotal / this.columns) * this.rowHeight) - this.verticalMargin;
  }

  getRow(index){
    return Math.floor(index / this.columns);
  }

  getColumn(index){
    return index - (this.getRow(index) * this.columns);
  }

  getPosition(index){
    var col = this.getColumn(index);
    var row = this.getRow(index);
    var margin = this.horizontalMargin;
    var width = this.itemWidth;

    return {
      x: Math.round((col * width) + (col * margin)),
      y: Math.round((this.itemHeight + this.verticalMargin) * row)
    };
  }

  getTransform(index){
    var position = this.getPosition(index);
    return 'translate3d(' + position.x + 'px, ' + position.y + 'px, 0)';
  }

  getStyle(index, animation, isFiltered){

    var transform = this.getTransform(index);
    var style = {
      width: this.itemWidth + 'px',
      height: this.itemHeight + 'px',
      WebkitTransform: transform,
      MozTransform: transform,
      msTransform: transform,
      transform: transform,
      position: 'absolute',
      boxSizing: 'border-box',
      display: isFiltered ? 'none' : 'block'
    };

    if(animation){
      style.WebkitTransition = '-webkit-' + animation;
      style.MozTransition = '-moz-' + animation;
      style.msTransition = 'ms-' + animation;
      style.transition = animation;
    }

    return style;
  }
}
