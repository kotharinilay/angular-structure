export default function isString(maybe) {
    return typeof maybe === 'string';
}
