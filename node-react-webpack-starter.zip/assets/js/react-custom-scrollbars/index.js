import Scrollbars from './Scrollbars';
export default Scrollbars;
export { Scrollbars };
