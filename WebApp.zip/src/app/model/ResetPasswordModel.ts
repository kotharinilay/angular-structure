export class ResetPasswordModel {
    public Id: string;
    public UserName: string;
    public Password: string;
    public ConfirmPassword: string;
    public CacheKey: string;
}