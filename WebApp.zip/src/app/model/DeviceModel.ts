export class DeviceListViewModel {
    public DeviceId: string;
    public ModelName: string;
    public Imei: string;
    public Phone: string;
    public SimId: string;
    public ClientName: string;
    public GroupName: string;
    public IsEnabled: boolean;
    public PurchaseDate: Date;
}