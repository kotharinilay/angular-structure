export class StatusDetailModel {
    public UpdateTimeUTC: string;
    public Speed: number = 0;
    public TimezoneRegion: string;
    public ReportingFrequency: number = 0;
}

export class ActivityStatusModel {
    public Status: string;
    public Description: string;
    public ColorCode: string;
}