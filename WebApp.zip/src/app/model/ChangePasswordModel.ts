export class ChangePasswordModel {
    public Id: string;
    public UserName: string;
    public OldPassword: string;
    public NewPassword: string;
    public ConfirmPassword: string;
}