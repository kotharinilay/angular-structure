export class ManufacturerModel {
    public ManufacturerId: string;
    public Name: string;
    public PhoneNumber: string;
    public Website: string;
    public IsDeleted: boolean;
}