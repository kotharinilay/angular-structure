export class FileStorageModel {
    public FileStorageId: string;
    public DisplayFileName: string;
    public FileAccessUrl: string;
    public MimeType: string;
}