export class LoginModel {
    public UserNmae: string;
    public Password: string;
    public RememberMe: boolean;
}