export class DropDownModel {    
    public Id: string;
    public Name: string;
}