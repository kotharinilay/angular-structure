export class ApiResponseModel {
  public StatusCode: number;
  public ErrorMessage: string;
  public Result: any;
}