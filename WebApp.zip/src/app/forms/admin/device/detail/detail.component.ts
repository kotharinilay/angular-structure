import { Component, OnInit } from '@angular/core';
import { NotifyService } from "app/services/notification.service";
import { DeviceService } from "app/forms/admin/device/device.service";
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmPopup } from "app/components/wrapper/confirm-popup";
import { DropDownViewModel, AssignOrUnassignViewModel } from "app/model/ClientModel";
import { BindingService } from "app/services/binding.service";

@Component({
  selector: 'device-detail',
  templateUrl: './detail.component.html'
})
export class DetailComponent implements OnInit {
  public paramId: string;
  model: any = {};
  public purchaseDate: Date;

  // Model Dropdown
  public defaultItemModel: AssignOrUnassignViewModel = { RoleName: "Select Model", RoleId: null, IsPeopleAssign: false };
  public modelData: Array<AssignOrUnassignViewModel> = [];
  public modelSource: Array<AssignOrUnassignViewModel> = [];
  public modelValue: AssignOrUnassignViewModel;

  // Carrier Dropdown
  public defaultItemCarrier: AssignOrUnassignViewModel = { RoleName: "Select Carrier", RoleId: null, IsPeopleAssign: false };
  public carrierData: Array<AssignOrUnassignViewModel> = [];
  public carrierSource: Array<AssignOrUnassignViewModel> = [];
  public carrierValue: AssignOrUnassignViewModel;

  // Condition Dropdown
  public conditionData: Array<DropDownViewModel> = [];
  public conditionValue: DropDownViewModel;


  // Entity Type Dropdown
  public entityTypeData: Array<DropDownViewModel> = [];
  public entityTypeValue: DropDownViewModel;

  // Client Dropdown
  public clientData: Array<AssignOrUnassignViewModel> = [];
  public clientSource: Array<AssignOrUnassignViewModel> = [];
  public clientValue: AssignOrUnassignViewModel;


  // Group Dropdown
  public groupData: Array<AssignOrUnassignViewModel> = [];
  public groupSource: Array<AssignOrUnassignViewModel> = [];
  public groupValue: AssignOrUnassignViewModel;


  // HardwareProfile Dropdown
  public hardwareProfileData: Array<AssignOrUnassignViewModel> = [];
  public hardwareProfileSource: Array<AssignOrUnassignViewModel> = [];
  public hardwareProfileValue: AssignOrUnassignViewModel;

  constructor(private notifyService: NotifyService, private bindingService: BindingService, private deviceService: DeviceService, private route: ActivatedRoute, private router: Router, private confirmPopup: ConfirmPopup) {
    this.conditionData = deviceService.setConditionSet();
    this.entityTypeData = deviceService.setEntityTypeSet();
  }

  ngOnInit() {
    this.conditionValue = this.conditionData[0];
    this.entityTypeValue = this.entityTypeData[0];
    this.route.params.subscribe(param => this.paramId = param["deviceId"].toLowerCase());
    if (this.paramId != "new") {
      this.deviceService.getById(this.paramId).subscribe(response => {
        this.model = response.Result;
        this.purchaseDate = new Date(this.model.PurchaseDate);
      });
    }
    this.deviceService.getModelList(this.paramId).subscribe(
      modelList => {
        this.modelSource = modelList.Result;
        this.modelData = this.modelSource.slice();
        this.modelData.forEach(element => {
          if (element.IsPeopleAssign) {
            this.modelValue = { RoleName: element.RoleName, RoleId: element.RoleId, IsPeopleAssign: element.IsPeopleAssign };
          }
        });
      });

    this.deviceService.getCarrierList(this.paramId).subscribe(
      carrierList => {
        this.carrierSource = carrierList.Result;
        this.carrierData = this.carrierSource.slice();
        this.carrierData.forEach(element => {
          if (element.IsPeopleAssign) {
            this.carrierValue = { RoleName: element.RoleName, RoleId: element.RoleId, IsPeopleAssign: element.IsPeopleAssign };
          }
        });
      });

  }


  ImeiHandler(event: any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 96 && charCode < 122) || (charCode > 64 && charCode < 90) || (charCode > 47 && charCode < 57) || (charCode == 8)) {
      return true;
    }
    return false;
  }

  protected modelFilterChange(filter: any): void {
    this.modelData = this.modelSource.filter((s) => s.RoleName.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }


  protected carrierFilterChange(filter: any): void {
    this.carrierData = this.carrierSource.filter((s) => s.RoleName.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }

  protected onModelChange(value: any): void {
    this.model.ModelId = value.Id;
  }

  protected onTabSelected(event: any) {
    if (event.title == "Client Configuration") {
      this.deviceService.getClientById(this.paramId).subscribe(response => {
        this.clientSource = response.Result;
        this.clientData = this.clientSource.slice();
        this.clientData.forEach(element => {
          if (element.IsPeopleAssign) {
            this.clientValue = { RoleName: element.RoleName, RoleId: element.RoleId, IsPeopleAssign: element.IsPeopleAssign };
            this.onClientChange(this.clientValue);
          }
        });
      });

      this.deviceService.getHardwareProfile(this.paramId).subscribe(response => {
        this.hardwareProfileSource = response.Result;
        this.hardwareProfileData = this.hardwareProfileSource.slice();
        this.hardwareProfileData.forEach(element => {
          if (element.IsPeopleAssign) {
            this.hardwareProfileValue = { RoleName: element.RoleName, RoleId: element.RoleId, IsPeopleAssign: element.IsPeopleAssign };
          }
        });
      });

    }
  }

  protected onClientChange(event: any) {
    this.deviceService.getGroupById(this.paramId, event.RoleId).subscribe(response => {
      this.groupSource = response.Result;
      this.groupData = this.groupSource.slice();
      this.groupData.forEach(element => {
        if (element.IsPeopleAssign) {
          this.groupValue = { RoleName: element.RoleName, RoleId: element.RoleId, IsPeopleAssign: element.IsPeopleAssign };
        }
      });
    });
  }
}
