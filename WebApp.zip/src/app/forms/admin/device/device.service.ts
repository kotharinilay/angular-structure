import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { DeviceListViewModel } from "app/model/DeviceModel";
import { State, toDataSourceRequestString } from '@progress/kendo-data-query';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Rx';
import { DropDownViewModel } from "app/model/ClientModel";
import { ApiResponseModel } from "app/model/ApiResponseModel";

@Injectable()
export class DeviceService {

  http: Http;
  allData: DeviceListViewModel[] = new Array<DeviceListViewModel>();
  allData$: BehaviorSubject<DeviceListViewModel[]>;


  constructor(_http: Http) {
    this.http = _http;
    this.allData$ = <BehaviorSubject<DeviceListViewModel[]>>new BehaviorSubject(new Array<DeviceListViewModel>());
  }

  setFilterDataSet() {
    var listItems: Array<DropDownViewModel> = [];
    listItems.push({ Id: "All", Name: "All" });
    listItems.push({ Id: "Imei", Name: "IMEI" });
    listItems.push({ Id: "ModelName ", Name: "Model Name" });
    listItems.push({ Id: "Phone", Name: "Phone" });
    listItems.push({ Id: "SimId", Name: "SIMID" });
    listItems.push({ Id: "ClientName", Name: "Client name" });
    listItems.push({ Id: "GroupName", Name: "Client Group" });
    return listItems;
  }

  setConditionSet() {
    var listItems: Array<DropDownViewModel> = [];
    listItems.push({ Id: "0", Name: "New" });
    listItems.push({ Id: "1", Name: "Used" });
    listItems.push({ Id: "2", Name: "Broken" });
    listItems.push({ Id: "3", Name: "Out For Repair" });
    return listItems;
  }

  setEntityTypeSet() {
    var listItems: Array<DropDownViewModel> = [];
    listItems.push({ Id: "0", Name: "Assest" });
    listItems.push({ Id: "1", Name: "Vehicle" });
    return listItems;
  }
  loadAll(state: State) {
    const queryStr = `${toDataSourceRequestString(state)}`;
    return this.http.get(`private/device/getall?${queryStr}`)
      .map(response => {
        let res = response.json();
        return (<GridDataResult>{
          data: res.Result.Data,
          total: res.Result.Total
        })
      })
      .subscribe((data: any) => {
        this.allData = data;
        this.allData$.next(data);
      });
  }
  subscribeToDataService(): Observable<DeviceListViewModel[]> {
    return this.allData$.asObservable();
  }

  remove(deviceId: string) {
    return this.http.get(`private/device/delete?id=${deviceId}`)
      .map(respose => respose.json());
  }

  downloadFile(state: State) {
    const queryStr = `${toDataSourceRequestString(state)}`;
    return this.http.get(`private/device/download?${queryStr}`)
      .map(respose => respose.json());
  }

  getModelList(id: string) {
    return this.http.get(`private/device/getmodellist?id=${id}`)
      .map(respose => respose.json());
  }

  getCarrierList(id: string) {
    return this.http.get(`private/device/getcarrierlist?id=${id}`)
      .map(respose => respose.json());
  }

  getById(id: string) {
    return this.http.get(`private/device/getbyid?id=${id}`)
      .map(respose => respose.json());
  }

  getClientById(id: string) {
    return this.http.get(`private/device/getclientlist?id=${id}`)
      .map(respose => respose.json());
  }

  getGroupById(id: string, clientId: string) {
    return this.http.get(`private/device/getgrouplist?id=${id}&clientId=${clientId}`)
      .map(respose => respose.json());
  }

  getHardwareProfile(id: string) {
    return this.http.get(`private/device/gethardwarelist?id=${id}`)
      .map(respose => respose.json());
  }

}
