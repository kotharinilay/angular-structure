import { Component } from '@angular/core';

@Component({
  selector: 'tracking-log',
  templateUrl: './tracking-log.component.html'
})

export class TrackingLogComponent {
  constructor() { }
}
