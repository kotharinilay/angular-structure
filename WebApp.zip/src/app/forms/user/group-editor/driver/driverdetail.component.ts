import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'group-editor-driver-detail',
  templateUrl: './driverdetail.component.html'
})

export class DriverDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
