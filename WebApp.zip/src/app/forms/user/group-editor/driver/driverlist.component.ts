import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'group-editor-driver-list',
  templateUrl: './driverlist.component.html'
})

export class DriverListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
