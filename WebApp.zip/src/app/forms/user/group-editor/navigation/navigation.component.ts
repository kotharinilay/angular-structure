import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'group-editor-navigation',
  templateUrl: './navigation.component.html'
})

export class NavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
