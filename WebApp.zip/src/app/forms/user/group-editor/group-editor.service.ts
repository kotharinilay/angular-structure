import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { ApiResponseModel } from "../../../model/ApiResponseModel";

import 'rxjs/add/operator/map';

@Injectable()
export class GroupEditorService {
    Http: Http;
    constructor(_http: Http) {
        this.Http = _http;
    }

    getGroupList(clientId: string) {
        return this.Http.get('/private/clientgroup/getclientgrouplist?clientId=' + clientId)
            .map(response => response.json());
    }

    getgroupvehiclelist() {
        return this.Http.get('/private/clientgroup/getgroupvehiclelist')
            .map(response => response.json());
    }
}