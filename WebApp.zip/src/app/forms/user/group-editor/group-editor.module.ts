import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouteModule } from './route';

import { GroupEditorComponent } from './group-editor.component';
import { NavigationComponent } from './navigation/navigation.component';
import { DriverListComponent } from './driver/driverlist.component';
import { DriverDetailComponent } from './driver/driverdetail.component';

@NgModule({
    imports: [
        CommonModule,
        RouteModule
    ],
    declarations: [GroupEditorComponent,NavigationComponent,DriverListComponent,DriverDetailComponent]
})
export class GroupEditorModule { } 