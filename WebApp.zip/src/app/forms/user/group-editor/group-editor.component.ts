import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-editor',
  templateUrl: './group-editor.component.html'
})

export class GroupEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 

}
 