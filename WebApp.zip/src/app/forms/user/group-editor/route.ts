import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GroupEditorComponent } from './group-editor.component';
import { DriverListComponent } from './driver/driverlist.component';
import { DriverDetailComponent } from './driver/driverdetail.component';

const routes: Routes = [
    {
        path: '', component: GroupEditorComponent,
        children: [
            { path: 'driver', component: DriverListComponent },
            { path: 'driver/detail', component: DriverDetailComponent }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class RouteModule { } 