import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { includes as _includes, map as _map } from "lodash";

import { Subject } from 'rxjs/Subject';
import "rxjs/add/operator/takeUntil";

import { PlaceService } from '../place.service';
import { NotifyService } from "app/services/notification.service";
import { mapOptions, getLatLng } from "app/shared/globals";

declare var google: any;

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html'
})

export class MapComponent implements OnInit, OnDestroy {

  // declare var for Add/Edit place
  @Input() detailPlace: boolean = false;
  @Input() placeId: string = "";
  @Output() drawPlaceArea = new EventEmitter();
  @Output() resetPlaceArea = new EventEmitter();

  ngUnsubscribe: Subject<void> = new Subject<void>();

  map: any = null;
  drawingManager: any = null;
  placeArea: any = null;
  addListener: boolean = false;

  // declare var for display/delete places
  placesArr: Array<any> = [];
  displayBounds: any = null;

  infoWindows: Array<any> = [];

  stockBlue: string = '#2a7ebb';
  stockBlack: string = '#555555';

  constructor(
    private placeService: PlaceService,
    private notifyService: NotifyService
  ) { }

  ngOnInit() {
    if (typeof google !== 'undefined') {
      this.loadMap();
    }
  }

  loadMap() {
    let mapProp = { center: new google.maps.LatLng(mapOptions.center), zoom: mapOptions.zoom };
    this.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    if (this.detailPlace) {
      // Create/Update Place
      this.drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: null,
        drawingControl: false,
        circleOptions: { editable: true },
        polygonOptions: { editable: true }
      });

      if (this.placeId == 'new') {
        // Create Place
        this.placeService.getDrawingMode()
          .takeUntil(this.ngUnsubscribe)
          .subscribe(obj => {
            if (obj && obj.drawingMode) {
              this.drawingManager.setDrawingMode(obj.drawingMode);
              this.drawingManager.setMap(this.map);

              if (this.drawingManager.drawingMode && !this.addListener) {
                let that = this;
                google.maps.event.addListener(this.drawingManager, 'overlaycomplete', function (e) {
                  that.placeArea = e.overlay;
                  that.drawingManager.setDrawingMode(null);
                  that.onClickPlaceArea(e);
                });
                this.onEscKeyUp();
              }
            }
          });
        this.addListener = true;
      }
      else {
        // Update Place
        this.placeService.subscribeToPlaceDetail()
          .takeUntil(this.ngUnsubscribe)
          .subscribe(place => {
            if (!place)
              return;

            let e = null;
            if (place.HasCircularGeofence) {
              this.placeArea = new google.maps.Circle({
                map: this.map,
                editable: true,
                center: getLatLng(place.CenterCoordinate),
                radius: Math.sqrt(place.SquareMeterArea / Math.PI)
              });
              e = { type: "circle", overlay: this.placeArea };
            }
            else {
              let coordinates = place.GeofenceCoordinates ? JSON.parse(place.GeofenceCoordinates) : [];
              this.placeArea = new google.maps.Polygon({
                map: this.map,
                editable: true,
                paths: coordinates
              });
              e = { type: "polygon", overlay: this.placeArea };
            }
            if (e)
              this.fitBoundToMap(e);

            this.placeService.getDrawingMode()
              .takeUntil(this.ngUnsubscribe)
              .subscribe(obj1 => {
                if (obj1 && obj1.drawingMode) {
                  this.drawingManager.setDrawingMode(obj1.drawingMode);
                  this.drawingManager.setMap(this.map);

                  if (this.drawingManager.drawingMode) {
                    let that = this;

                    if (!this.addListener) {
                      google.maps.event.addListener(this.drawingManager, 'overlaycomplete', function (e) {
                        that.placeArea = e.overlay;
                        that.drawingManager.setDrawingMode(null);
                        that.onClickPlaceArea(e);
                      });
                      this.addListener = true;
                    }
                  }
                }
              });
            this.onClickPlaceArea(e);
            this.onEscKeyUp();
          });
      }
    }
    else {
      // Display Places
      this.placeService.subscribeToPlaces()
        .takeUntil(this.ngUnsubscribe)
        .subscribe(places => {
          if (places) {
            // reset all shape
            this.placesArr.map(place => {
              place.shape.setMap(null);
            });

            let bounds = new google.maps.LatLngBounds();
            places.map(place => {
              var shape = null;
              if (place.HasCircularGeofence) {
                shape = new google.maps.Circle({
                  strokeColor: this.stockBlack,
                  center: getLatLng(place.CenterCoordinate),
                  radius: Math.sqrt(place.SquareMeterArea / Math.PI)
                });
                bounds.union(shape.getBounds());
              }
              else {
                let coordinates = place.GeofenceCoordinates ? JSON.parse(place.GeofenceCoordinates) : [];
                shape = new google.maps.Polygon({
                  strokeColor: this.stockBlack,
                  paths: coordinates
                });
                bounds.union(shape.getBounds());
              }

              this.placesArr.push({ shape: shape, id: place.PlaceId });

              shape.infoWindow = new google.maps.InfoWindow({ content: `<b>${place.Name}</b>` });
              shape.infoWindow.setPosition(getLatLng(place.CenterCoordinate));

              let that = this;
              google.maps.event.addListener(shape, "mouseover", function () { that.shapeOver(shape) });
              google.maps.event.addListener(shape, "mouseout", function () { that.shapeOut(shape) });

              var placeElement = document.getElementById(place.PlaceId);
              if (placeElement) {
                placeElement.addEventListener("mouseover", function () { that.shapeOver(shape, bounds) });
                placeElement.addEventListener("mouseout", function () { that.shapeOut(shape) });

                placeElement.addEventListener("click", function () {
                  if (place.HasCircularGeofence)
                    that.fitBoundToMap({ type: 'circle', overlay: shape });
                  else
                    that.fitBoundToMap({ type: 'polygon', overlay: shape });
                });
              }
              shape.setMap(this.map);
            });
            this.map.fitBounds(bounds);
            this.displayBounds = bounds;
          }
        });
    }

  }

  // mouseover event of place/shape
  shapeOver(shape, bounds = null) {
    if (bounds)
      this.map.fitBounds(bounds);
    shape.setOptions({ strokeColor: this.stockBlue, fillColor: this.stockBlue });
    shape.infoWindow.open(this.map, shape);
  }

  // mouseout event of place/shape
  shapeOut(shape) {
    shape.setOptions({ strokeColor: this.stockBlack, fillColor: this.stockBlack });
    shape.infoWindow.close();
  }

  // handle click event of placearea
  onClickPlaceArea(e) {
    let that = this;
    google.maps.event.addListener(this.placeArea, 'click', function (e) {
      // Check if click was on a vertex control point
      if (e.vertex == undefined)
        return;
      if (that.placeArea.getPath().getLength() < 4) {
        that.notifyService.alert('Polygon must be required minimum three points.');
        return;
      }

      var div = document.createElement('div');
      div.className = 'delete-place';
      div.innerHTML = 'Delete';

      var menu = this;
      google.maps.event.addDomListener(div, 'click', function (event) {
        that.placeArea.getPath().removeAt(e.vertex);
        that.closeAllInfoWindows();
      });

      var infowindow = new google.maps.InfoWindow({
        position: e.latLng,
        content: div
      });
      infowindow.open(this.map);
      that.infoWindows.push(infowindow);
    });

    if (e.type == 'polygon') {
      var place_polygon_path = that.placeArea.getPath()
      google.maps.event.addListener(place_polygon_path, 'set_at', function () {
        that.drawPlace(e);
      });
      google.maps.event.addListener(place_polygon_path, 'insert_at', function () {
        that.drawPlace(e);
      });
      google.maps.event.addListener(place_polygon_path, 'remove_at', function () {
        that.drawPlace(e);
      });
    }
    else {
      google.maps.event.addListener(that.placeArea, 'radius_changed', function () {
        that.drawPlace(e);
      });
      google.maps.event.addListener(that.placeArea, 'center_changed', function () {
        that.drawPlace(e);
      });
      that.placeService.getCircleRadius()
        .takeUntil(this.ngUnsubscribe)
        .subscribe(obj => {
          if (obj && obj.radius)
            that.placeArea.setRadius(obj.radius);
        });
    }

    that.drawPlace(e);

  }

  // handle Esc key event
  onEscKeyUp() {
    let that = this;
    google.maps.event.addDomListener(document, 'keyup', function (e) {
      var code = (e.keyCode ? e.keyCode : e.which);
      if (code === 27) {
        that.closeAllInfoWindows();
        that.drawingManager.setDrawingMode(null);
        if (that.placeArea)
          that.placeArea.setMap(null);
        that.resetPlaceArea.emit(null);
      }
    });
  }

  // draw place on event changed
  drawPlace(e) {
    this.fitBoundToMap(e);
    this.drawPlaceArea.emit(e);
  }

  // set bounds to map
  fitBoundToMap(e) {
    var bounds = new google.maps.LatLngBounds();
    bounds.union(e.overlay.getBounds());
    this.map.fitBounds(bounds);
  }

  // close all infowindows
  closeAllInfoWindows() {
    for (var i = 0; i < this.infoWindows.length; i++) {
      this.infoWindows[i].close();
    }
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();

    this.placeService.clearDrawingMode();
    this.placeService.clearCircleRadius();
    this.placeService.clearPlaceDetail();
  }

}
