import { Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PanelBarExpandMode } from '@progress/kendo-angular-layout';
import { PlaceModel } from 'app/model/Place';
import { MapService } from 'app/services/map.service';
import { NotifyService } from 'app/services/notification.service';
import { valDuplicateInputStyle } from 'app/shared/globals';
import { DigitDecimalPipe } from 'app/shared/utility.pipe';
import { PlaceService } from '../place.service';

declare var google: any;

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  providers: [DigitDecimalPipe]
})

export class DetailComponent implements OnInit {

  placeModel: PlaceModel = new PlaceModel();
  mapReady: boolean = false;

  _valDuplicateInputStyle = valDuplicateInputStyle;

  handMode: any;
  circleMode: any;
  polygonMode: any;

  mode: any = PanelBarExpandMode.Single;
  drawType: string = '';
  isDrawPolygon: boolean = false;
  isDrawPlace: boolean = false;

  loadingPlace: boolean = false;
  isDuplicatePlace: boolean = null;
  loadingSave: boolean = false;
  isInvalidRadius: boolean = false;

  placeId: string = "";

  constructor(
    private zone: NgZone,
    private router: Router,
    private placeService: PlaceService,
    private digitDecimalPipe: DigitDecimalPipe,
    private notifyService: NotifyService,
    private activatedRoute: ActivatedRoute
  ) {
    this.activatedRoute.params.subscribe(param => this.placeId = param["placeId"]);

  }

  ngOnInit() {
    this.placeModel.HasCircularGeofence = true;
    MapService.load().then(res => {
      this.mapReady = true;
      this.initDrawingManager();

      if (this.placeId != 'new') {
        this.placeService.loadPlaceById(this.placeId).subscribe(res => { }, err => {
          this.router.navigate(['/user/places']);
        });
        this.placeService.subscribeToPlaceDetail().subscribe(place => {
          if (!place)
            return;

          this.placeModel = {
            PlaceId: place.PlaceId,
            PeopleId: place.PeopleId,
            ClientId: place.ClientId,
            Name: place.Name,
            SquareMeterArea: place.SquareMeterArea,
            HasCircularGeofence: place.HasCircularGeofence,
            GeofenceCoordinates: place.GeofenceCoordinates,
            CenterCoordinate: place.CenterCoordinate,
            Radius: place.HasCircularGeofence ? Math.sqrt(place.SquareMeterArea / Math.PI) : 0
          };

          if (place.HasCircularGeofence) {
            this.setDrawMode(this.handMode);
            this.isDrawPolygon = false;
            this.isDrawPlace = true;
          }
        })
      }
      else {
        this.placeModel.HasCircularGeofence = true;
        this.setDrawMode(this.circleMode);
      }
    });
  }

  initDrawingManager() {
    this.handMode = null;
    this.circleMode = google.maps.drawing.OverlayType.CIRCLE;
    this.polygonMode = google.maps.drawing.OverlayType.POLYGON;
  }

  // on selection of draw type (Circular/Polygon)
  changeDrawType(drawPolygon = this.isDrawPolygon) {
    this.isDrawPolygon = drawPolygon;
    if (this.isDrawPolygon) {
      this.placeModel.HasCircularGeofence = false;
      this.setDrawMode(this.polygonMode);
    }
    else {
      this.placeModel.HasCircularGeofence = true;
      this.setDrawMode(this.circleMode);
    }
  }

  // set draw mode to map
  setDrawMode(mode) {
    this.drawType = mode;
    this.placeService.setDrawingMode(mode);
  }

  // set draw place to true
  drawPlace(e) {
    let overlay = e.overlay;
    let isPolygon = this.isDrawPolygon = e.type == 'polygon';
    this.setDrawMode(this.handMode);

    if (isPolygon) {
      // get array of coordinates
      let cords = [];
      let polygonPath = overlay.getPath();
      for (var i = 0; i < polygonPath.getLength(); i++) {
        let cord = polygonPath.getAt(i);
        cords.push({ lat: cord.lat(), lng: cord.lng() });
      }

      // get center coordinate
      var bounds = new google.maps.LatLngBounds();
      overlay.getPath().forEach(function (element, index) { bounds.extend(element); });
      let centerCord = bounds.getCenter();

      this.placeModel.CenterCoordinate = centerCord.lat() + "," + centerCord.lng();
      this.placeModel.GeofenceCoordinates = JSON.stringify(cords);
      this.placeModel.SquareMeterArea = this.digitDecimalPipe.transform(google.maps.geometry.spherical.computeArea(overlay.getPath()), 4);
      this.placeModel.Radius = 0;
    }
    else {
      let centerCord = overlay.getCenter();

      this.placeModel.CenterCoordinate = centerCord.lat() + "," + centerCord.lng();
      this.placeModel.GeofenceCoordinates = null;
      let radius = overlay.getRadius();
      this.placeModel.SquareMeterArea = this.digitDecimalPipe.transform((radius * radius * Math.PI), 4);
      this.placeModel.Radius = radius;
    }
    this.zone.run(() => this.isDrawPlace = true);
  }

  // change radius of circle
  changeRadius(event: Event) {
    if (!this.isDrawPolygon) {
      let value = (<HTMLInputElement>event.target).value;
      let radius = value ? parseFloat(value) : 0;

      if (value == '') {
        this.isInvalidRadius = false;
        return;
      } else if (radius == 0) {
        this.isInvalidRadius = true;
        return;
      }
      this.isInvalidRadius = false;
      this.placeService.setCircleRadius(radius); // Math.sqrt(value / Math.PI)
      this.placeModel.SquareMeterArea = Math.PI * radius * radius;
    }
  }

  // reset place area for redraw
  resetPlace() {
    this.isInvalidRadius = false;
    this.isDrawPlace = false;
    this.changeDrawType();
  }

  // on change event of place 
  placeChange(event: Event) {
    let text = (<HTMLInputElement>event.target).value;
    if (text != '') {
      this.loadingPlace = true;
      this.placeService.checkDuplicate(text, this.placeId).subscribe(res => {
        this.isDuplicatePlace = res.Result
        this.loadingPlace = false;
      }, err => {
        this.loadingPlace = false;
      });
    }
    else {
      this.isDuplicatePlace = null;
      this.loadingPlace = false;
    }
  }

  // add place
  addPlace() {
    if (this.isDuplicatePlace) {
      this.notifyService.error('Place Name is already exist.');
      return;
    }
    this.loadingSave = true;
    this.placeService.save(this.placeModel).subscribe(response => {
      this.loadingSave = false;
      this.notifyService.success(this.placeModel.PlaceId ? "Place updated successfully." : "Place created successfully.");
      this.router.navigate(['/user/places']);
    }, err => this.loadingSave = false);
  }

}
