import { Component, OnInit } from '@angular/core';
import { ConfirmPopup } from 'app/components/wrapper/confirm-popup';
import { MapService } from 'app/services/map.service';
import { NotifyService } from 'app/services/notification.service';
import { startsWith as _startsWith } from 'lodash';
import { PlaceService } from '../place.service';

@Component({
  selector: 'places-display',
  templateUrl: './display.component.html'
})

export class DisplayComponent implements OnInit {

  mapReady = false;
  loadingPlaces: boolean = false;
  placesData: any = [];
  places: any = [];

  constructor(
    private mapService: MapService,
    private placeService: PlaceService,
    private confirmPopup: ConfirmPopup,
    private notifyService: NotifyService
  ) { }

  ngOnInit() {
    MapService.load().then(res => {
      this.mapReady = true;
    });

    this.loadPlacesData();
  }

  // load places data from db
  loadPlacesData() {
    this.loadingPlaces = true;
    this.placeService.getAllPlaces().subscribe(res => {
      this.loadingPlaces = false;
      this.places = this.placesData = res.Result;
      let that = this;
      setTimeout(function () {
        that.placeService.setPlaces(that.places);
      }, 500);
    }, err => this.loadingPlaces = false);
  }

  // handle keyup for search textbox
  searchKeyUp(e, element) {
    var code = (e.keyCode ? e.keyCode : e.which);
    if (code === 27) {
      this.clearFilter(element);
    }
  }

  // filter for search places
  searchPlaces(event: Event) {
    let searchText = (<HTMLInputElement>event.target).value.toLowerCase();
    this.places = this.placesData.filter(p => _startsWith(p.Name.toLowerCase(), searchText));
  }

  // clear filter
  clearFilter(element: HTMLInputElement) {
    this.places = this.placesData;
    element.value = ''
  }

  // delete place
  deletePlace(placeId) {
    this.confirmPopup.openConfirmation("Are you sure to delete this Place?").then(res => {
      this.placeService.delete(placeId).subscribe(res => {
        this.loadPlacesData();
        this.notifyService.success('Place deleted successfully.');
      });
    });
  }

  ngOnDestroy() {
    this.placeService.clearPlaces();
  }
}
