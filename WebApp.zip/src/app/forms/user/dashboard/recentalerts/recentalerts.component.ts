import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-recentalerts',
  templateUrl: './recentalerts.component.html',
  styleUrls: ['./recentalerts.component.css']
})
export class RecentalertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
