import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { startsWith as _startsWith } from "lodash";

import { GroupEditorService } from "app/forms/user/group-editor/group-editor.service";
import { CommonService } from "app/services/common.service";

import * as moment from 'moment';

@Component({
  selector: 'user-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {

  authUserObj: any;
  private subscriptions: Subscription[] = [];
  private clientGropus: any = [];
  private filterGroups: any = [];
  private groupSerach: string;
  private loadingGroups: boolean = false;
  _moment = moment;

  constructor(private _groupService: GroupEditorService, private commonService: CommonService) {
    this.authUserObj = this.commonService.AuthUser.getValue();
  }

  ngOnInit() {
    this.loadingGroups = true;
    this.subscriptions.push(this._groupService.getGroupList(this.authUserObj.ClientId).subscribe(grps => {
      this.loadingGroups = false;
      this.clientGropus = this.filterGroups = grps.Result;
    }, err => { this.loadingGroups = false; }));
  }

  searchGroup() {
    this.filterGroups = this.clientGropus.filter(grp => _startsWith(grp.Name.toLowerCase(), this.groupSerach));
  }

  clearFilter() {
    this.filterGroups = this.clientGropus;
    this.groupSerach = '';
  }

}
