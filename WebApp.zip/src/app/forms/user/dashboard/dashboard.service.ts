import { Injectable } from '@angular/core';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Http } from '@angular/http';
import { AnnouncementModel, DisplayAnnouncementModel } from "app/model/DashboardModel";
import { Observable } from "rxjs/Observable";
import { ApiResponseModel } from "app/model/ApiResponseModel";

@Injectable()
export class DashboardService {
  http: Http;
  public newAnnouncement = new BehaviorSubject(null);

  constructor(_http: Http) {
    this.http = _http;
  }

  // Save announcement
  saveAnnouncement(announcementObj: AnnouncementModel): Observable<ApiResponseModel> {
    return this.http.post('private/dashboard/saveannouncement', announcementObj)
      .map(response => response.json());
  }

  // get all announcements
  getAnnouncements(peopleId: string): Observable<ApiResponseModel> {
    return this.http.get('private/dashboard/getannouncement', { params: { peopleId: peopleId } })
      .map(response => response.json());
  }

  setNewAnnouncement(announcement) {
    this.newAnnouncement.next(announcement);
  }
}
