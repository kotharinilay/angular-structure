import { DatePipe } from '@angular/common';
import { Subject } from 'rxjs/Subject';
import "rxjs/add/operator/takeUntil";
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';

import { map as _map } from "lodash";
import * as moment from 'moment';

import { FleetService } from "../fleet.service";
import { MapService } from '../../../../services/map.service';

@Component({
  selector: 'fleet-logbook',
  templateUrl: './logbook.component.html',
  providers: [DatePipe]
})

export class LogbookComponent implements OnInit, OnDestroy {

  ngUnsubscribe: Subject<void> = new Subject<void>();
  mapReady: boolean = false;

  id = null;
  logbookData = null;
  dateValue: Date = new Date();

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private fleetService: FleetService
  ) {
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(param => {
      this.id = param["id"];
      MapService.load().then(res => {
        this.mapReady = true;
      });
      this.loadVehicleDetails();
    });
  }

  loadVehicleDetails() {
    this.fleetService.getVehicleById(this.id, this.dateValue).takeUntil(this.ngUnsubscribe).subscribe(res => {
      this.logbookData = res;
    }, err => {
      this.router.navigate(['/user/fleet']);
    });
  }

  onDateChange(value) {
    this.dateValue = value;
    this.loadVehicleDetails();
  }

  onApplyFilter(times = null) {
    let data = Object.assign({}, this.logbookData);
    if (times) {

      //apply time filter
      let timeFormat = "HH:mm";
      let startTime = moment(times.startTime, timeFormat);
      let endTime = moment(times.endTime, timeFormat);

      if (data && data.VehicleTrips) {
        let trips = [];
        _map(data.VehicleTrips, d => {

          let jsTime = d.JourneyStartDate ? moment(moment(d.JourneyStartDate).format(timeFormat), timeFormat) : moment('00:00', timeFormat);
          let jeTime = d.JourneyEndDate ? moment(moment(d.JourneyEndDate).format(timeFormat), timeFormat) : moment('00:00', timeFormat);

          if ((jsTime && (jsTime.isBetween(startTime, endTime) || jsTime.isSame(startTime) || jsTime.isSame(endTime))) ||
            (jeTime && (jeTime.isBetween(startTime, endTime) || jeTime.isSame(startTime) || jeTime.isSame(endTime)))) {
            trips.push(d);
          }

        });
        data.VehicleTrips = trips;
      }

    }
    this.fleetService.setVehicleDetail(data);
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
